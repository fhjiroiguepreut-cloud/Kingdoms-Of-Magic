class_name Interactable
extends Node3D
## Punto interactuable con la tecla E.

var prompt := "Interactuar"
var cb: Callable
var range_m := 3.2
var enabled := true


static func make(parent: Node, pos: Vector3, prompt_text: String, callback: Callable, r: float = 3.2) -> Interactable:
	var i := Interactable.new()
	i.prompt = prompt_text
	i.cb = callback
	i.range_m = r
	parent.add_child(i)
	i.global_position = pos
	i.add_to_group("interact")
	return i


func trigger(p: Node) -> void:
	if enabled and cb.is_valid():
		cb.call(p)
