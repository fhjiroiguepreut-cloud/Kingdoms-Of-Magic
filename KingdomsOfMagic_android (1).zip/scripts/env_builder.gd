class_name EnvBuilder
extends RefCounted
## Cielo, iluminación global, niebla volumétrica, glow, SSAO/SSIL/SSR/SDFGI y tonemapping.

static func build(parent: Node3D) -> Dictionary:
	var mobile := OS.has_feature("mobile")
	var we := WorldEnvironment.new()
	var env := Environment.new()
	var sky := Sky.new()
	var psm := ProceduralSkyMaterial.new()
	psm.sky_top_color = Color(0.16, 0.38, 0.78)
	psm.sky_horizon_color = Color(0.72, 0.8, 0.92)
	psm.ground_horizon_color = Color(0.7, 0.76, 0.84)
	psm.ground_bottom_color = Color(0.2, 0.3, 0.42)
	psm.sun_angle_max = 30.0
	psm.sun_curve = 0.15
	sky.sky_material = psm
	sky.process_mode = Sky.PROCESS_MODE_AUTOMATIC if mobile else Sky.PROCESS_MODE_REALTIME
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.9
	env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
	env.tonemap_mode = Environment.TONE_MAPPER_ACES
	env.tonemap_exposure = 1.0
	env.tonemap_white = 6.0
	# Iluminación global y oclusión (bajar si el equipo es modesto)
	if not mobile: env.ssao_enabled = true
	if not mobile: env.ssao_radius = 1.6
	if not mobile: env.ssao_intensity = 2.0
	if not mobile: env.ssil_enabled = true
	if not mobile: env.ssr_enabled = true
	if not mobile: env.sdfgi_enabled = true
	if not mobile: env.sdfgi_use_occlusion = true
	if not mobile: env.sdfgi_energy = 0.9
	# Bloom
	env.glow_enabled = true
	env.glow_intensity = 0.9
	env.glow_bloom = 0.12
	env.glow_hdr_threshold = 0.9
	env.glow_blend_mode = Environment.GLOW_BLEND_MODE_SOFTLIGHT
	# Niebla de distancia + volumétrica
	env.fog_enabled = true
	env.fog_light_color = Color(0.7, 0.8, 0.92)
	env.fog_density = 0.0006
	env.fog_aerial_perspective = 0.4
	env.fog_sky_affect = 0.3
	if not mobile: env.volumetric_fog_enabled = true
	if not mobile: env.volumetric_fog_density = 0.011
	if not mobile: env.volumetric_fog_albedo = Color(0.85, 0.9, 1.0)
	if not mobile: env.volumetric_fog_gi_inject = 0.8
	if not mobile: env.volumetric_fog_anisotropy = 0.6
	if not mobile: env.volumetric_fog_length = 140.0
	if not mobile: env.volumetric_fog_detail_spread = 2.0
	if not mobile: env.volumetric_fog_ambient_inject = 0.5
	# Corrección de color
	env.adjustment_enabled = true
	env.adjustment_saturation = 1.15
	env.adjustment_contrast = 1.06
	we.environment = env
	parent.add_child(we)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-34.0, -35.0, 0.0)
	sun.light_color = Color(1.0, 0.93, 0.8)
	sun.light_energy = 1.9
	sun.shadow_enabled = true
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS
	sun.directional_shadow_max_distance = 220.0
	sun.light_angular_distance = 0.5
	sun.light_volumetric_fog_energy = 1.6
	if mobile:
		sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
		sun.directional_shadow_max_distance = 120.0
	parent.add_child(sun)
	return {"env": env, "sun": sun}
