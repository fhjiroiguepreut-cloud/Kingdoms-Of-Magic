class_name Terrain
extends RefCounted
## Malla del terreno (con vértices coloreados por altura/pendiente/camino) y agua.

const WATER_SHADER := """
shader_type spatial;
uniform vec4 deep_color : source_color = vec4(0.02, 0.16, 0.28, 1.0);
uniform vec4 shallow_color : source_color = vec4(0.12, 0.55, 0.58, 1.0);
uniform sampler2D wave_normal : hint_normal, repeat_enable, filter_linear_mipmap;
uniform sampler2D depth_tex : hint_depth_texture, filter_nearest;

void vertex() {
	VERTEX.y += sin(VERTEX.x * 0.05 + TIME * 0.8) * 0.25 + cos(VERTEX.z * 0.07 + TIME * 0.6) * 0.2;
}

void fragment() {
	vec2 uv = UV * 450.0;
	vec3 n1 = texture(wave_normal, uv + vec2(TIME * 0.02, TIME * 0.01)).rgb;
	vec3 n2 = texture(wave_normal, uv * 1.7 - vec2(TIME * 0.015, TIME * 0.02)).rgb;
	NORMAL_MAP = normalize(mix(n1, n2, 0.5));
	NORMAL_MAP_DEPTH = 0.8;
	float depth = texture(depth_tex, SCREEN_UV).x;
	vec3 ndc = vec3(SCREEN_UV * 2.0 - 1.0, depth);
	vec4 view = INV_PROJECTION_MATRIX * vec4(ndc, 1.0);
	view.xyz /= view.w;
	float wd = max(-view.z + VERTEX.z, 0.0);
	vec3 col = mix(shallow_color.rgb, deep_color.rgb, smoothstep(0.0, 9.0, wd));
	float foam = (1.0 - smoothstep(0.0, 0.7, wd)) * (0.6 + 0.4 * sin(TIME * 2.0 + UV.x * 900.0));
	float fres = pow(1.0 - clamp(dot(NORMAL, VIEW), 0.0, 1.0), 4.0);
	ALBEDO = mix(col, vec3(0.75, 0.88, 1.0), fres * 0.5) + vec3(foam * 0.8);
	ALPHA = clamp(0.35 + wd / 3.5, 0.0, 0.96);
	ROUGHNESS = 0.04;
	SPECULAR = 0.8;
	METALLIC = 0.0;
}
"""


static func color_at(x: float, z: float, h: float, slope: float, pd: float) -> Color:
	var gm := Island.hill_n.get_noise_2d(x * 2.5, z * 2.5) * 0.5 + 0.5
	var c: Color
	if h < 0.3:
		c = Color(0.32, 0.34, 0.3).lerp(Color(0.6, 0.55, 0.4), clampf((h + 6.0) / 6.0, 0.0, 1.0))
	elif h < 2.0:
		c = Color(0.84, 0.76, 0.56)
	else:
		c = Color(0.17, 0.36, 0.1).lerp(Color(0.34, 0.52, 0.16), gm)
		c = Color(0.84, 0.76, 0.56).lerp(c, smoothstep(2.0, 3.4, h))
	var rock := Color(0.4, 0.38, 0.37).lerp(Color(0.52, 0.5, 0.47), gm)
	c = c.lerp(rock, maxf(smoothstep(0.55, 0.95, slope), smoothstep(20.0, 30.0, h)))
	c = c.lerp(Color(0.92, 0.94, 0.98), smoothstep(40.0, 50.0, h) * (1.0 - smoothstep(0.7, 1.1, slope)))
	if pd < 3.2 and h > 1.5:
		c = c.lerp(Color(0.46, 0.34, 0.22), smoothstep(3.2, 1.6, pd))
	return c


static func build(parent: Node3D) -> void:
	var n := Island.gn
	var ext := Island.EXT
	var step := Island.STEP
	var hs := PackedFloat32Array()
	hs.resize(n * n)
	for j in n:
		for i in n:
			hs[j * n + i] = Island.height(-ext + i * step, -ext + j * step)
	var verts := PackedVector3Array()
	var norms := PackedVector3Array()
	var cols := PackedColorArray()
	verts.resize(n * n)
	norms.resize(n * n)
	cols.resize(n * n)
	for j in n:
		for i in n:
			var x := -ext + i * step
			var z := -ext + j * step
			var k := j * n + i
			var h := hs[k]
			var hl := hs[j * n + maxi(i - 1, 0)]
			var hr := hs[j * n + mini(i + 1, n - 1)]
			var hu := hs[maxi(j - 1, 0) * n + i]
			var hd := hs[mini(j + 1, n - 1) * n + i]
			var nx := (hl - hr) / (2.0 * step)
			var nz := (hu - hd) / (2.0 * step)
			verts[k] = Vector3(x, h, z)
			norms[k] = Vector3(nx, 1.0, nz).normalized()
			cols[k] = color_at(x, z, h, sqrt(nx * nx + nz * nz), Island.pgrid[k])
	var idx := PackedInt32Array()
	for j in n - 1:
		for i in n - 1:
			var a := j * n + i
			var b := a + 1
			var c := a + n
			var d := c + 1
			idx.append_array(PackedInt32Array([a, b, c, b, d, c]))
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_NORMAL] = norms
	arrays[Mesh.ARRAY_COLOR] = cols
	arrays[Mesh.ARRAY_INDEX] = idx
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	var body := StaticBody3D.new()
	body.name = "Terreno"
	parent.add_child(body)
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = Gfx.terrain_mat()
	body.add_child(mi)
	var cs := CollisionShape3D.new()
	cs.shape = mesh.create_trimesh_shape()
	body.add_child(cs)


static func build_water(parent: Node3D) -> void:
	var pm := PlaneMesh.new()
	pm.size = Vector2(3600, 3600)
	var sub := 80 if OS.has_feature("mobile") else 180
	pm.subdivide_width = sub
	pm.subdivide_depth = sub
	var sh := Shader.new()
	sh.code = WATER_SHADER
	var m := ShaderMaterial.new()
	m.shader = sh
	var nt := NoiseTexture2D.new()
	var nn := FastNoiseLite.new()
	nn.frequency = 0.02
	nn.fractal_octaves = 3
	nt.noise = nn
	nt.seamless = true
	nt.as_normal_map = true
	nt.bump_strength = 4.0
	nt.width = 256 if OS.has_feature("mobile") else 512
	nt.height = nt.width
	m.set_shader_parameter("wave_normal", nt)
	var mi := MeshInstance3D.new()
	mi.name = "Mar"
	mi.mesh = pm
	mi.material_override = m
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
