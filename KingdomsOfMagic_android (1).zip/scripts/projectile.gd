class_name Projectile
extends Area3D
## Proyectil mágico (jugador u hostil).

var dir := Vector3.FORWARD
var speed := 30.0
var damage := 15.0
var hostile := false
var color := Color(0.5, 0.7, 1.0)
var aoe := 0.0
var life := 3.0
var size := 0.25
var done := false


static func fire(parent: Node, pos: Vector3, direction: Vector3, is_hostile: bool, col: Color, dmg: float, spd: float, area: float = 0.0, sz: float = 0.25) -> Projectile:
	var p := Projectile.new()
	p.dir = direction.normalized()
	p.hostile = is_hostile
	p.color = col
	p.damage = dmg
	p.speed = spd
	p.aoe = area
	p.size = sz
	parent.add_child(p)
	p.global_position = pos
	return p


func _ready() -> void:
	collision_layer = 0
	collision_mask = 1 | (2 if hostile else 4)
	monitoring = true
	var cs := CollisionShape3D.new()
	var sh := SphereShape3D.new()
	sh.radius = size * 1.3
	cs.shape = sh
	add_child(cs)
	Gfx.glow_node(self, Gfx.sphere_mesh(size), Vector3.ZERO, color, 6.0)
	Gfx.light(self, Vector3.ZERO, color, 2.5, 7.0)
	var tr := Fx.particles(color, 36, 0.5, size * 1.6, Vector2(0.0, 0.5), size * 0.4, Vector3.ZERO)
	add_child(tr)
	body_entered.connect(_on_body)


func _physics_process(delta: float) -> void:
	global_position += dir * speed * delta
	life -= delta
	if life <= 0.0:
		_explode()


func _on_body(b: Node) -> void:
	if hostile:
		if b.is_in_group("player"):
			b.take_damage(damage, self)
	elif b.is_in_group("enemy"):
		b.take_damage(damage, self)
	_explode()


func _explode() -> void:
	if done:
		return
	done = true
	Fx.burst(get_parent(), global_position, color, 36, 0.35, 6.0)
	if aoe > 0.0:
		for e in get_tree().get_nodes_in_group("player" if hostile else "enemy"):
			if e.global_position.distance_to(global_position) < aoe:
				e.take_damage(damage * 0.6, self)
	queue_free()
