class_name TouchControls
extends CanvasLayer
## Controles táctiles para Android: joystick flotante (izquierda), botones (derecha)
## y cámara por arrastre (resto de la pantalla derecha).

const STICK_R := 130.0

var player: Player
var cam: CinematicCamera
var main: Node

var canvas: Control
var size_v := Vector2(1920, 1080)
var stick_id := -1
var stick_origin := Vector2.ZERO
var stick_vec := Vector2.ZERO
var look_id := -1
var btn_ids := {}
var buttons := {}


func _ready() -> void:
	layer = 20
	canvas = Control.new()
	canvas.set_anchors_preset(Control.PRESET_FULL_RECT)
	canvas.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(canvas)
	canvas.draw.connect(_draw_ui)
	get_viewport().size_changed.connect(_layout)
	_layout()


func _layout() -> void:
	size_v = get_viewport().get_visible_rect().size
	var w := size_v.x
	var h := size_v.y
	buttons = {
		"attack": {"pos": Vector2(w - 190.0, h - 190.0), "r": 90.0, "label": "ATAQUE"},
		"jump": {"pos": Vector2(w - 380.0, h - 110.0), "r": 60.0, "label": "SALTO"},
		"interact": {"pos": Vector2(w - 110.0, h - 380.0), "r": 60.0, "label": "E"},
		"s1": {"pos": Vector2(w - 400.0, h - 260.0), "r": 48.0, "label": "1"},
		"s2": {"pos": Vector2(w - 290.0, h - 340.0), "r": 48.0, "label": "2"},
		"s3": {"pos": Vector2(w - 200.0, h - 470.0), "r": 48.0, "label": "3"},
	}


func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			_press(event.index, event.position)
		else:
			_release(event.index)
	elif event is InputEventScreenDrag:
		_drag(event.index, event.position, event.relative)


func _press(idx: int, p: Vector2) -> void:
	if not main.started:
		main.start_game()
		return
	if not player.controls_enabled:
		return
	for n in buttons:
		var b: Dictionary = buttons[n]
		if p.distance_to(b["pos"]) <= float(b["r"]) * 1.15:
			btn_ids[idx] = n
			_button_down(n)
			return
	if p.x < size_v.x * 0.45:
		if stick_id == -1:
			stick_id = idx
			stick_origin = p
			stick_vec = Vector2.ZERO
	elif look_id == -1:
		look_id = idx


func _release(idx: int) -> void:
	if idx == stick_id:
		stick_id = -1
		stick_vec = Vector2.ZERO
		_apply_stick(Vector2.ZERO)
	if idx == look_id:
		look_id = -1
	if btn_ids.has(idx):
		btn_ids.erase(idx)


func _drag(idx: int, p: Vector2, rel: Vector2) -> void:
	if idx == stick_id:
		var v := p - stick_origin
		if v.length() > STICK_R:
			stick_origin += v.normalized() * (v.length() - STICK_R)
			v = p - stick_origin
		_apply_stick(v / STICK_R)
	elif idx == look_id:
		if cam.mode == CinematicCamera.Mode.FOLLOW:
			cam.yaw -= rel.x * cam.sens * 1.6
			cam.pitch = clampf(cam.pitch - rel.y * cam.sens * 1.6, -1.2, 0.7)


func _set_action(action: String, strength: float) -> void:
	if strength > 0.05:
		Input.action_press(action, strength)
	else:
		Input.action_release(action)


func _apply_stick(v: Vector2) -> void:
	stick_vec = v
	_set_action("move_right", maxf(v.x, 0.0))
	_set_action("move_left", maxf(-v.x, 0.0))
	_set_action("move_back", maxf(v.y, 0.0))
	_set_action("move_forward", maxf(-v.y, 0.0))
	if v.length() > 0.9:
		Input.action_press("sprint")
	else:
		Input.action_release("sprint")


func _button_down(n: String) -> void:
	match n:
		"attack":
			player.cast_spell()
		"jump":
			player.jump_req = true
		"interact":
			if player.near_inter != null:
				player.near_inter.trigger(player)
		"s1":
			player._select(0)
		"s2":
			player._select(1)
		"s3":
			player._select(2)


func _process(_delta: float) -> void:
	if main.started and btn_ids.values().has("attack") and player.controls_enabled:
		player.cast_spell()
	canvas.queue_redraw()


func _draw_ui() -> void:
	if not main.started:
		return
	var font := ThemeDB.fallback_font
	if stick_id != -1:
		canvas.draw_circle(stick_origin, STICK_R, Color(1, 1, 1, 0.12))
		canvas.draw_arc(stick_origin, STICK_R, 0.0, TAU, 48, Color(1, 1, 1, 0.35), 3.0)
		canvas.draw_circle(stick_origin + stick_vec * STICK_R, 52.0, Color(1, 1, 1, 0.35))
	else:
		canvas.draw_arc(Vector2(260.0, size_v.y - 230.0), STICK_R, 0.0, TAU, 48, Color(1, 1, 1, 0.15), 3.0)
	var held: Array = btn_ids.values()
	for n in buttons:
		var b: Dictionary = buttons[n]
		var pos: Vector2 = b["pos"]
		var r: float = b["r"]
		var down: bool = held.has(n)
		var sel: bool = (n == "s1" and player.spell == 0) or (n == "s2" and player.spell == 1) or (n == "s3" and player.spell == 2)
		var fill := Color(0.6, 0.5, 1.0, 0.55) if (down or sel) else Color(1, 1, 1, 0.16)
		canvas.draw_circle(pos, r, fill)
		canvas.draw_arc(pos, r, 0.0, TAU, 40, Color(1, 1, 1, 0.5), 3.0)
		var fs := 26 if r > 55.0 else 30
		canvas.draw_string(font, pos + Vector2(-r, fs * 0.35), str(b["label"]), HORIZONTAL_ALIGNMENT_CENTER, r * 2.0, fs, Color(1, 1, 1, 0.95))
