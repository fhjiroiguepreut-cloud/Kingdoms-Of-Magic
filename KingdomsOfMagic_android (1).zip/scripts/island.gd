class_name Island
extends RefCounted
## Datos del mundo: altura del terreno, caminos, zonas y áreas excluidas.

const RADIUS := 170.0
const SANCT := Vector2(-20.0, -88.0)
const SANCT_Y := 26.0
const ACADEMY_Y := 8.0
const LAKE := Vector2(75.0, 55.0)
const EXT := 215.0
static var STEP := 3.0 if OS.has_feature("mobile") else 2.0

static var base_n: FastNoiseLite
static var hill_n: FastNoiseLite
static var ridge_n: FastNoiseLite
static var forest_n: FastNoiseLite
static var villages: Array = []
static var port: Vector3 = Vector3.ZERO
static var mine_entrance: Vector3 = Vector3.ZERO
static var paths: Array = []
static var keepout: Array = []   # Vector3(x, z, radio)
static var zones: Array = []     # {name, pos(Vector2), r, danger}
static var pgrid := PackedFloat32Array()
static var gn := 0


static func setup(seed_value: int = 1337) -> void:
	base_n = FastNoiseLite.new()
	base_n.seed = seed_value
	base_n.frequency = 0.012
	base_n.fractal_octaves = 4
	hill_n = FastNoiseLite.new()
	hill_n.seed = seed_value + 3
	hill_n.frequency = 0.04
	ridge_n = FastNoiseLite.new()
	ridge_n.seed = seed_value + 7
	ridge_n.frequency = 0.018
	ridge_n.fractal_type = FastNoiseLite.FRACTAL_RIDGED
	forest_n = FastNoiseLite.new()
	forest_n.seed = seed_value + 99
	forest_n.frequency = 0.022
	keepout.clear()
	zones.clear()
	villages = [
		{"name": "Roblealto", "pos": Vector2(-95, 55), "n": 9},
		{"name": "Piedra Clara", "pos": Vector2(95, -45), "n": 8},
		{"name": "Valle Brumoso", "pos": Vector2(45, 102), "n": 7},
	]
	port = find_coast(deg_to_rad(86.0))
	mine_entrance = find_mine()
	paths = [
		make_path(Vector2(0, 17), Vector2(port.x, port.z)),
		make_path(Vector2(-4, 17), villages[0]["pos"]),
		make_path(Vector2(4, 17), villages[1]["pos"]),
		make_path(Vector2(2, 17), villages[2]["pos"]),
		make_path(Vector2(0, -16), Vector2(SANCT.x, SANCT.y + 26.0)),
		make_path(Vector2(14, -16), Vector2(mine_entrance.x, mine_entrance.z + 5.0)),
	]
	_build_path_grid()


static func river_x(z: float) -> float:
	return -70.0 + sin(z * 0.035) * 18.0


static func height(x: float, z: float) -> float:
	var p := Vector2(x, z)
	var d := p.length() / RADIUS
	d += base_n.get_noise_2d(x * 1.7 + 300.0, z * 1.7) * 0.12
	var mask := smoothstep(1.0, 0.55, d)
	var h := 5.0 + base_n.get_noise_2d(x, z) * 5.0 + hill_n.get_noise_2d(x, z) * 2.5
	var mt := smoothstep(-25.0, -110.0, z)
	h += mt * (14.0 + (ridge_n.get_noise_2d(x, z) * 0.5 + 0.5) * 28.0)
	h = h * mask + (1.0 - mask) * -14.0
	h = lerpf(h, ACADEMY_Y, smoothstep(48.0, 30.0, p.length()))
	h = lerpf(h, SANCT_Y, smoothstep(40.0, 24.0, p.distance_to(SANCT)))
	h = lerpf(h, -5.0, smoothstep(34.0, 18.0, p.distance_to(LAKE)))
	var carve := smoothstep(9.0, 3.0, absf(x - river_x(z))) * smoothstep(-70.0, -40.0, z)
	h = lerpf(h, -1.8, carve)
	return h


static func slope(x: float, z: float) -> float:
	var dx := (height(x + 1.5, z) - height(x - 1.5, z)) / 3.0
	var dz := (height(x, z + 1.5) - height(x, z - 1.5)) / 3.0
	return sqrt(dx * dx + dz * dz)


static func forest_density(x: float, z: float) -> float:
	return forest_n.get_noise_2d(x, z) * 0.5 + 0.5


static func make_path(a: Vector2, b: Vector2, wob: float = 6.0) -> PackedVector2Array:
	var pts := PackedVector2Array()
	var dir := b - a
	var perp := Vector2(-dir.y, dir.x).normalized()
	var n := 10
	for i in n + 1:
		var t := float(i) / n
		pts.append(a.lerp(b, t) + perp * sin(t * TAU + a.x * 0.1) * wob * sin(t * PI))
	return pts


static func _build_path_grid() -> void:
	gn = int(EXT * 2.0 / STEP) + 1
	pgrid = PackedFloat32Array()
	pgrid.resize(gn * gn)
	pgrid.fill(99.0)
	for path in paths:
		for i in path.size() - 1:
			var a: Vector2 = path[i]
			var b: Vector2 = path[i + 1]
			var seg_len := a.distance_to(b)
			var steps := int(seg_len) + 1
			for s in steps + 1:
				var p := a.lerp(b, float(s) / steps)
				var gi := roundi((p.x + EXT) / STEP)
				var gj := roundi((p.y + EXT) / STEP)
				for dj in range(-3, 4):
					for di in range(-3, 4):
						var ii := gi + di
						var jj := gj + dj
						if ii < 0 or jj < 0 or ii >= gn or jj >= gn:
							continue
						var q := Vector2(-EXT + ii * STEP, -EXT + jj * STEP)
						var d := q.distance_to(p)
						var idx := jj * gn + ii
						if d < pgrid[idx]:
							pgrid[idx] = d


static func path_d(x: float, z: float) -> float:
	var ii := clampi(roundi((x + EXT) / STEP), 0, gn - 1)
	var jj := clampi(roundi((z + EXT) / STEP), 0, gn - 1)
	return pgrid[jj * gn + ii]


static func excluded(x: float, z: float, extra: float = 0.0) -> bool:
	for k in keepout:
		if Vector2(x, z).distance_to(Vector2(k.x, k.y)) < k.z + extra:
			return true
	return false


static func find_coast(ang: float) -> Vector3:
	var dir := Vector2(cos(ang), sin(ang))
	var r := 100.0
	while r < 260.0 and height(dir.x * r, dir.y * r) > 0.6:
		r += 1.0
	while r > 60.0 and height(dir.x * r, dir.y * r) < 1.8:
		r -= 1.0
	return Vector3(dir.x * r, height(dir.x * r, dir.y * r), dir.y * r)


static func find_mine() -> Vector3:
	var x := 48.0
	var z := -45.0
	while z > -140.0:
		if height(x, z) >= 13.0:
			break
		z -= 1.0
	return Vector3(x, height(x, z), z)
