class_name Enemy
extends CharacterBody3D
## Criaturas mágicas: slime arcano, lobo espectral, fuego fatuo y golem de cristal.

signal died(enemy)

const GRAV := 22.0
static var _mesh_cache := {}

var kind := "slime"
var hp := 30.0
var max_hp := 30.0
var speed := 3.0
var dmg := 8.0
var aggro := 16.0
var home := Vector3.ZERO
var atk_cd := 0.0
var wander_t := 0.0
var wander_dir := Vector3.ZERO
var visual: Node3D
var player: Node3D
var phase := 0.0
var flying := false
var ranged := false
var punch := 0.0
var moving := false
var dead := false


static func create(parent: Node, k: String, pos: Vector3) -> Enemy:
	var e := Enemy.new()
	e.kind = k
	parent.add_child(e)
	e.global_position = pos
	e.home = pos
	return e


func _ready() -> void:
	add_to_group("enemy")
	collision_layer = 4
	collision_mask = 1
	phase = randf() * 10.0
	var r := 0.6
	var hgt := 1.2
	match kind:
		"slime":
			hp = 35.0; speed = 2.6; dmg = 7.0; aggro = 14.0; r = 0.8; hgt = 1.5
		"wolf":
			hp = 55.0; speed = 6.5; dmg = 11.0; aggro = 22.0; r = 0.6; hgt = 1.2
		"wisp":
			hp = 28.0; speed = 3.5; dmg = 9.0; aggro = 20.0; r = 0.4; hgt = 0.9; flying = true; ranged = true
		"golem":
			hp = 140.0; speed = 2.4; dmg = 22.0; aggro = 18.0; r = 1.1; hgt = 3.0
	max_hp = hp
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = r
	cap.height = maxf(hgt, r * 2.0 + 0.1)
	cs.shape = cap
	cs.position.y = cap.height * 0.5
	add_child(cs)
	visual = _build_visual()
	add_child(visual)


func _make_mesh(k: String) -> ArrayMesh:
	var parts: Array = []
	match k:
		"slime":
			parts = [
				Gfx.p_sph(0.09, Vector3(-0.28, 0.85, -0.62), Color.WHITE, Vector3.ONE, 8),
				Gfx.p_sph(0.09, Vector3(0.28, 0.85, -0.62), Color.WHITE, Vector3.ONE, 8),
				Gfx.p_sph(0.045, Vector3(-0.28, 0.85, -0.7), Color.BLACK, Vector3.ONE, 6),
				Gfx.p_sph(0.045, Vector3(0.28, 0.85, -0.7), Color.BLACK, Vector3.ONE, 6),
			]
		"wolf":
			var c := Color(0.5, 0.58, 0.78)
			var d := Color(0.35, 0.4, 0.6)
			parts = [
				Gfx.p_box(Vector3(0.7, 0.7, 1.5), Vector3(0, 0.85, 0), c),
				Gfx.p_box(Vector3(0.5, 0.45, 0.55), Vector3(0, 1.05, -0.95), c),
				Gfx.p_box(Vector3(0.25, 0.2, 0.4), Vector3(0, 0.95, -1.35), d),
				Gfx.p_box(Vector3(0.12, 0.25, 0.1), Vector3(-0.17, 1.4, -0.9), d),
				Gfx.p_box(Vector3(0.12, 0.25, 0.1), Vector3(0.17, 1.4, -0.9), d),
				Gfx.p_box(Vector3(0.18, 0.7, 0.18), Vector3(-0.25, 0.35, -0.55), d),
				Gfx.p_box(Vector3(0.18, 0.7, 0.18), Vector3(0.25, 0.35, -0.55), d),
				Gfx.p_box(Vector3(0.18, 0.7, 0.18), Vector3(-0.25, 0.35, 0.55), d),
				Gfx.p_box(Vector3(0.18, 0.7, 0.18), Vector3(0.25, 0.35, 0.55), d),
				Gfx.p_box(Vector3(0.15, 0.15, 0.8), Vector3(0, 1.1, 1.1), c, Vector3(-30, 0, 0)),
			]
		"golem":
			var s := Color(0.3, 0.3, 0.35)
			var m := Color(0.22, 0.34, 0.24)
			parts = [
				Gfx.p_box(Vector3(1.7, 1.8, 1.2), Vector3(0, 2.0, 0), s),
				Gfx.p_box(Vector3(0.9, 0.7, 0.9), Vector3(0, 3.15, -0.1), s),
				Gfx.p_box(Vector3(0.5, 1.7, 0.5), Vector3(-1.2, 2.0, 0), s),
				Gfx.p_box(Vector3(0.5, 1.7, 0.5), Vector3(1.2, 2.0, 0), s),
				Gfx.p_box(Vector3(0.75, 0.75, 0.75), Vector3(-1.2, 0.95, 0), s),
				Gfx.p_box(Vector3(0.75, 0.75, 0.75), Vector3(1.2, 0.95, 0), s),
				Gfx.p_box(Vector3(0.6, 1.1, 0.6), Vector3(-0.45, 0.55, 0), s),
				Gfx.p_box(Vector3(0.6, 1.1, 0.6), Vector3(0.45, 0.55, 0), s),
				Gfx.p_box(Vector3(1.0, 0.3, 0.7), Vector3(0.1, 2.95, 0.35), m),
			]
	if parts.is_empty():
		return null
	return Gfx.merge(parts)


func _build_visual() -> Node3D:
	var root := Node3D.new()
	if not _mesh_cache.has(kind):
		_mesh_cache[kind] = _make_mesh(kind)
	var body_mesh: ArrayMesh = _mesh_cache[kind]
	if body_mesh != null:
		Gfx.add_mesh(root, body_mesh)
	match kind:
		"slime":
			var sm := Gfx.sphere_mesh(0.85)
			var mi := Gfx.add_mesh(root, sm, Vector3(0, 0.7, 0), Gfx.glass(Color(0.3, 1.0, 0.5, 0.7)))
			mi.scale = Vector3(1.0, 0.85, 1.0)
			Gfx.glow_node(root, Gfx.sphere_mesh(0.22), Vector3(0, 0.6, 0), Color(0.6, 1.0, 0.7), 3.0)
			Gfx.light(root, Vector3(0, 0.8, 0), Color(0.4, 1.0, 0.6), 0.8, 5.0)
		"wolf":
			Gfx.glow_node(root, Gfx.box_mesh(Vector3(0.1, 0.07, 0.05)), Vector3(-0.13, 1.1, -1.22), Color(0.4, 0.9, 1.0), 5.0)
			Gfx.glow_node(root, Gfx.box_mesh(Vector3(0.1, 0.07, 0.05)), Vector3(0.13, 1.1, -1.22), Color(0.4, 0.9, 1.0), 5.0)
			root.add_child(Fx.particles(Color(0.5, 0.7, 1.0), 20, 1.2, 0.25, Vector2(0.1, 0.4), 0.5, Vector3(0, 0.5, 0)))
		"wisp":
			Gfx.glow_node(root, Gfx.sphere_mesh(0.28), Vector3.ZERO, Color(1.0, 0.65, 0.2), 5.0)
			Gfx.light(root, Vector3.ZERO, Color(1.0, 0.6, 0.2), 2.0, 9.0)
			root.add_child(Fx.particles(Color(1.0, 0.7, 0.3), 30, 1.0, 0.3, Vector2(0.2, 0.8), 0.2, Vector3(0, 0.3, 0)))
		"golem":
			Gfx.glow_node(root, Gfx.box_mesh(Vector3(0.14, 0.1, 0.06)), Vector3(-0.2, 3.2, -0.57), Color(0.4, 0.95, 1.0), 6.0)
			Gfx.glow_node(root, Gfx.box_mesh(Vector3(0.14, 0.1, 0.06)), Vector3(0.2, 3.2, -0.57), Color(0.4, 0.95, 1.0), 6.0)
			for i in 4:
				var cone := CylinderMesh.new()
				cone.top_radius = 0.0
				cone.bottom_radius = 0.22
				cone.height = 1.1
				cone.radial_segments = 6
				var n := Gfx.glow_node(root, cone, Vector3(-0.6 + i * 0.4, 3.2, 0.5), Color(0.35, 0.85, 1.0), 3.0)
				n.rotation_degrees = Vector3(randf_range(-20, 20), 0, randf_range(-20, 20))
			Gfx.light(root, Vector3(0, 3.4, 0.6), Color(0.4, 0.9, 1.0), 1.4, 9.0)
	return root


func _process(delta: float) -> void:
	if visual == null:
		return
	var t := Time.get_ticks_msec() / 1000.0 + phase
	var s := Vector3.ONE
	match kind:
		"slime":
			var k := sin(t * (7.0 if moving else 3.0))
			s = Vector3(1.0 + 0.09 * k, 1.0 - 0.12 * k, 1.0 + 0.09 * k)
		"wolf":
			visual.position.y = absf(sin(t * 11.0)) * 0.12 if moving else 0.0
		"wisp":
			visual.position.y = 1.5 + sin(t * 2.0) * 0.25
		"golem":
			visual.rotation.z = sin(t * (3.0 if moving else 1.5)) * 0.04
	punch = maxf(0.0, punch - delta * 2.5)
	visual.scale = s * (1.0 + punch)


func _physics_process(delta: float) -> void:
	if dead:
		return
	if player == null:
		player = get_tree().get_first_node_in_group("player")
	atk_cd -= delta
	var want := Vector3.ZERO
	var dist := 999.0
	var d := Vector3.ZERO
	if player != null:
		var to_p := player.global_position - global_position
		d = Vector3(to_p.x, 0, to_p.z)
		dist = d.length()
		d = d.normalized()
	if player != null and dist < aggro and player.hp > 0.0:
		if ranged:
			if dist > 10.0:
				want = d
			elif dist < 5.0:
				want = -d
			if atk_cd <= 0.0 and dist < 17.0:
				atk_cd = 2.0
				var from := global_position + Vector3(0, 1.4, 0)
				var tgt: Vector3 = player.global_position + Vector3(0, 1.1, 0)
				Projectile.fire(get_parent(), from, (tgt - from).normalized(), true, Color(1.0, 0.55, 0.2), dmg, 16.0, 0.0, 0.22)
		else:
			if dist > 2.1:
				want = d
			elif atk_cd <= 0.0:
				atk_cd = 1.3
				player.take_damage(dmg, self)
				velocity += d * 5.0
		_face(d, delta)
	else:
		wander_t -= delta
		if wander_t <= 0.0:
			wander_t = randf_range(2.0, 5.0)
			var ang := randf() * TAU
			wander_dir = Vector3(cos(ang), 0, sin(ang)) if randf() < 0.6 else Vector3.ZERO
			if global_position.distance_to(home) > 12.0:
				wander_dir = (home - global_position).normalized() * Vector3(1, 0, 1)
		want = wander_dir * 0.4
		if want.length() > 0.05:
			_face(want.normalized(), delta)
	moving = want.length() > 0.05
	velocity.x = lerpf(velocity.x, want.x * speed, 1.0 - exp(-8.0 * delta))
	velocity.z = lerpf(velocity.z, want.z * speed, 1.0 - exp(-8.0 * delta))
	if flying:
		var gh := Island.height(global_position.x, global_position.z) if global_position.y > -20.0 else global_position.y
		velocity.y = (gh + 1.8 - global_position.y) * 2.5
	elif not is_on_floor():
		velocity.y -= GRAV * delta
	move_and_slide()
	if global_position.y < -40.0 and global_position.y > -60.0:
		global_position = home


func _face(d: Vector3, delta: float) -> void:
	rotation.y = lerp_angle(rotation.y, atan2(-d.x, -d.z), 1.0 - exp(-8.0 * delta))


func take_damage(amount: float, src: Node = null) -> void:
	if dead:
		return
	hp -= amount
	punch = 0.3
	Fx.dmg_text(get_parent(), global_position + Vector3(0, 2.2, 0), amount)
	if src is Node3D:
		var kb := (global_position - (src as Node3D).global_position)
		kb.y = 0.0
		velocity += kb.normalized() * 4.0
	if hp <= 0.0:
		_die()


func _die() -> void:
	dead = true
	var col := Color(0.6, 0.9, 1.0)
	Fx.burst(get_parent(), global_position + Vector3(0, 1, 0), col, 60, 0.5, 8.0)
	var cam := get_tree().get_first_node_in_group("cam")
	if cam:
		cam.shake(0.2)
	if player and player.global_position.distance_to(global_position) < 25.0:
		player.restore(5.0, 18.0)
	died.emit(self)
	queue_free()
