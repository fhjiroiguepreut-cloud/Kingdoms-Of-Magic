class_name Player
extends CharacterBody3D
## Mago jugable: movimiento relativo a cámara, AnimationTree (idle/walk/run/cast), hechizos y interacción.

const WALK := 6.0
const RUN := 11.5
const JUMP := 8.0
const GRAV := 24.0
const SPELLS := [
	{"name": "Bola Arcana", "kind": "bolt", "cost": 6.0, "cd": 0.35, "dmg": 18.0, "speed": 38.0, "size": 0.25, "col": Color(0.6, 0.5, 1.0)},
	{"name": "Rayo de Escarcha", "kind": "bolt", "cost": 14.0, "cd": 0.8, "dmg": 34.0, "speed": 64.0, "size": 0.18, "col": Color(0.5, 0.92, 1.0)},
	{"name": "Nova de Fuego", "kind": "nova", "cost": 30.0, "cd": 3.0, "dmg": 45.0, "speed": 0.0, "size": 0.0, "col": Color(1.0, 0.5, 0.15)},
]

var hp := 100.0
var max_hp := 100.0
var mana := 100.0
var max_mana := 100.0
var controls_enabled := false
var cam: CinematicCamera
var hud: HUD
var main: Node
var rig: Node3D
var tree: AnimationTree
var playback: AnimationNodeStateMachinePlayback
var cur_anim := ""
var cast_t := 0.0
var cd := 0.0
var spell := 0
var invuln := 0.0
var spawn_pos := Vector3.ZERO
var near_inter: Interactable
var combat_check := 0.0
var dying := false
var jump_req := false


func _ready() -> void:
	add_to_group("player")
	collision_layer = 2
	collision_mask = 1
	floor_max_angle = deg_to_rad(58.0)
	floor_snap_length = 0.6
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.35
	cap.height = 1.8
	cs.shape = cap
	cs.position.y = 0.9
	add_child(cs)
	rig = CharacterRig.create(Color(0.35, 0.2, 0.68), Color(0.92, 0.75, 0.25), Color(0.25, 0.15, 0.55))
	add_child(rig)
	var ap := CharacterRig.animator(self)
	# --- AnimationTree con máquina de estados ---
	tree = AnimationTree.new()
	tree.name = "AnimationTree"
	add_child(tree)
	var sm := AnimationNodeStateMachine.new()
	var names := ["idle", "walk", "run", "cast"]
	for n in names:
		var an := AnimationNodeAnimation.new()
		an.animation = n
		sm.add_node(n, an)
	for a in names:
		for b in names:
			if a != b:
				var t := AnimationNodeStateMachineTransition.new()
				t.xfade_time = 0.18
				sm.add_transition(a, b, t)
	var start_t := AnimationNodeStateMachineTransition.new()
	start_t.advance_mode = AnimationNodeStateMachineTransition.ADVANCE_MODE_AUTO
	sm.add_transition("Start", "idle", start_t)
	tree.tree_root = sm
	tree.anim_player = tree.get_path_to(ap)
	tree.active = true
	Gfx.light(self, Vector3(0, 2.2, 0), Color(0.6, 0.7, 1.0), 0.5, 7.0)


func _unhandled_input(event: InputEvent) -> void:
	if not controls_enabled:
		return
	if event.is_action_pressed("attack") and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		cast_spell()
	elif event.is_action_pressed("spell_1"):
		_select(0)
	elif event.is_action_pressed("spell_2"):
		_select(1)
	elif event.is_action_pressed("spell_3"):
		_select(2)
	elif event.is_action_pressed("interact") and near_inter != null:
		near_inter.trigger(self)


func _select(i: int) -> void:
	spell = i
	hud.select_spell(i)


func _physics_process(delta: float) -> void:
	if hud == null or cam == null:
		return
	invuln -= delta
	cd -= delta
	cast_t -= delta
	mana = minf(max_mana, mana + 5.0 * delta)
	hud.set_hp(hp, max_hp)
	hud.set_mana(mana, max_mana)
	if playback == null:
		playback = tree.get("parameters/playback")
	var input := Vector2.ZERO
	if controls_enabled and not dying:
		input = Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var dir := Vector3(input.x, 0, input.y).rotated(Vector3.UP, cam.yaw)
	var sprint := Input.is_action_pressed("sprint") and input.length() > 0.1 and controls_enabled
	var in_water := global_position.y < 0.5 and main != null and main.area == "outside"
	var sp := RUN if sprint else WALK
	if in_water:
		sp *= 0.55
	velocity.x = lerpf(velocity.x, dir.x * sp, 1.0 - exp(-12.0 * delta))
	velocity.z = lerpf(velocity.z, dir.z * sp, 1.0 - exp(-12.0 * delta))
	if not is_on_floor():
		velocity.y -= GRAV * delta
	elif controls_enabled and not dying and (Input.is_action_just_pressed("jump") or jump_req):
		velocity.y = JUMP
	jump_req = false
	move_and_slide()
	# Orientación del modelo
	if cast_t > 0.0:
		var f := -cam.global_transform.basis.z
		rig.rotation.y = lerp_angle(rig.rotation.y, atan2(-f.x, -f.z), 1.0 - exp(-18.0 * delta))
	elif dir.length() > 0.1:
		rig.rotation.y = lerp_angle(rig.rotation.y, atan2(-dir.x, -dir.z), 1.0 - exp(-10.0 * delta))
	# Animación
	var want := "idle"
	if cast_t > 0.0:
		want = "cast"
	elif input.length() > 0.1:
		want = "run" if sprint else "walk"
	if playback != null and want != cur_anim:
		cur_anim = want
		playback.travel(want)
	cam.sprint_fov = 7.0 if (sprint and is_on_floor()) else 0.0
	# Límites del mundo
	if main != null:
		if main.area == "outside":
			var r := Vector2(global_position.x, global_position.z)
			if r.length() > 198.0:
				r = r.normalized() * 198.0
				global_position.x = r.x
				global_position.z = r.y
				hud.toast("Necesitas un barco para viajar más lejos")
			if global_position.y < -30.0:
				_respawn()
		elif global_position.y < -110.0:
			_respawn()
	_update_interact()
	combat_check -= delta
	if combat_check <= 0.0:
		combat_check = 0.3
		var near := 0.0
		for e in get_tree().get_nodes_in_group("enemy"):
			if e.global_position.distance_to(global_position) < 16.0:
				near = 1.0
				break
		cam.in_combat = lerpf(cam.in_combat, near, 0.6)


func _update_interact() -> void:
	var best: Interactable = null
	var bd := 999.0
	if controls_enabled:
		for n in get_tree().get_nodes_in_group("interact"):
			var it := n as Interactable
			if it == null or not it.enabled:
				continue
			var d := global_position.distance_to(it.global_position)
			if d < it.range_m and d < bd:
				bd = d
				best = it
	near_inter = best
	hud.set_prompt("[E] " + best.prompt if best != null else "")


func cast_spell() -> void:
	var s: Dictionary = SPELLS[spell]
	if cd > 0.0 or mana < s["cost"] or dying:
		return
	mana -= s["cost"]
	cd = s["cd"]
	cast_t = 0.55
	await get_tree().create_timer(0.18).timeout
	var origin := global_position + Vector3(0, 1.7, 0)
	var col: Color = s["col"]
	if s["kind"] == "bolt":
		var aim := cam.aim_point()
		var d := (aim - origin).normalized()
		Projectile.fire(get_parent(), origin + d * 0.8, d, false, col, s["dmg"], s["speed"], 0.0, s["size"])
		cam.punch(2.0)
	else:
		Fx.burst(get_parent(), global_position + Vector3(0, 0.6, 0), col, 140, 0.7, 14.0)
		var ring := MeshInstance3D.new()
		var tm := TorusMesh.new()
		tm.inner_radius = 0.9
		tm.outer_radius = 1.0
		ring.mesh = tm
		ring.material_override = Gfx.glow(col, 4.0)
		get_parent().add_child(ring)
		ring.global_position = global_position + Vector3(0, 0.4, 0)
		var tw := ring.create_tween().set_parallel(true)
		tw.tween_property(ring, "scale", Vector3(7.5, 1.0, 7.5), 0.35)
		tw.chain().tween_callback(ring.queue_free)
		for e in get_tree().get_nodes_in_group("enemy"):
			if e.global_position.distance_to(global_position) < 8.0:
				e.take_damage(s["dmg"], self)
		cam.shake(0.5)
		cam.punch(6.0)


func restore(m: float, h: float) -> void:
	mana = minf(max_mana, mana + m)
	hp = minf(max_hp, hp + h)


func take_damage(a: float, _src: Node = null) -> void:
	if invuln > 0.0 or hp <= 0.0 or dying:
		return
	hp -= a
	invuln = 0.45
	hud.flash_damage()
	cam.shake(0.4)
	cam.punch(-3.0)
	if hp <= 0.0:
		_die()


func _die() -> void:
	dying = true
	controls_enabled = false
	hud.say("Has caído... la magia antigua te devuelve a la Academia.", 4.0)
	cam.hit_stop(0.25, 0.2)
	await get_tree().create_timer(1.4).timeout
	await hud.fade(true, 0.7)
	_respawn()
	await hud.fade(false, 0.8)
	dying = false
	controls_enabled = true


func _respawn() -> void:
	hp = max_hp
	mana = max_mana
	velocity = Vector3.ZERO
	global_position = spawn_pos
	if main != null:
		main.set_area("outside")
	cam.snap_behind(0.0)
