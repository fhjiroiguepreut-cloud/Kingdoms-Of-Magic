class_name Fx
extends RefCounted
## Efectos: partículas 3D mágicas, ráfagas, niebla local y números de daño.

static var _tex: GradientTexture2D
static var _mat: StandardMaterial3D


static func glow_mat() -> StandardMaterial3D:
	if _mat == null:
		var g := Gradient.new()
		g.offsets = PackedFloat32Array([0.0, 0.5, 1.0])
		g.colors = PackedColorArray([Color(1, 1, 1, 1), Color(1, 1, 1, 0.35), Color(1, 1, 1, 0)])
		_tex = GradientTexture2D.new()
		_tex.gradient = g
		_tex.fill = GradientTexture2D.FILL_RADIAL
		_tex.fill_from = Vector2(0.5, 0.5)
		_tex.fill_to = Vector2(1.0, 0.5)
		_tex.width = 64
		_tex.height = 64
		_mat = StandardMaterial3D.new()
		_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		_mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
		_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		_mat.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
		_mat.billboard_keep_scale = true
		_mat.vertex_color_use_as_albedo = true
		_mat.albedo_texture = _tex
		_mat.particles_anim_h_frames = 1
		_mat.particles_anim_v_frames = 1
		_mat.particles_anim_loop = false
		_mat.disable_receive_shadows = true
	return _mat


static func particles(col: Color, amount: int, life: float, size: float, vel: Vector2, radius: float, grav: Vector3, spread: float = 180.0, dir: Vector3 = Vector3.UP, one_shot: bool = false, burst: float = 0.0) -> GPUParticles3D:
	var p := GPUParticles3D.new()
	p.amount = amount
	p.lifetime = life
	p.one_shot = one_shot
	p.explosiveness = burst
	p.emitting = not one_shot
	var pm := ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_SPHERE
	pm.emission_sphere_radius = maxf(radius, 0.01)
	pm.direction = dir
	pm.spread = spread
	pm.initial_velocity_min = vel.x
	pm.initial_velocity_max = vel.y
	pm.gravity = grav
	pm.scale_min = 0.6
	pm.scale_max = 1.4
	var g := Gradient.new()
	g.offsets = PackedFloat32Array([0.0, 0.2, 1.0])
	g.colors = PackedColorArray([Color(col.r, col.g, col.b, 0.0), col, Color(col.r, col.g, col.b, 0.0)])
	var gt := GradientTexture1D.new()
	gt.gradient = g
	pm.color_ramp = gt
	p.process_material = pm
	var q := QuadMesh.new()
	q.size = Vector2(size, size)
	q.material = glow_mat()
	p.draw_pass_1 = q
	p.visibility_aabb = AABB(Vector3(-40, -40, -40), Vector3(80, 80, 80))
	p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	return p


static func ambient(parent: Node, pos: Vector3, col: Color, amount: int = 30, radius: float = 2.0, size: float = 0.12) -> GPUParticles3D:
	var p := particles(col, amount, 4.0, size, Vector2(0.1, 0.5), radius, Vector3(0, 0.25, 0))
	p.position = pos
	parent.add_child(p)
	return p


static func burst(parent: Node, pos: Vector3, col: Color, amount: int = 40, size: float = 0.4, speed: float = 6.0) -> void:
	var p := particles(col, amount, 0.8, size, Vector2(speed * 0.4, speed), 0.2, Vector3(0, -6, 0), 180.0, Vector3.UP, true, 1.0)
	parent.add_child(p)
	p.global_position = pos
	p.emitting = true
	var l := OmniLight3D.new()
	l.light_color = col
	l.light_energy = 4.0
	l.omni_range = 9.0
	parent.add_child(l)
	l.global_position = pos
	var tw := l.create_tween()
	tw.tween_property(l, "light_energy", 0.0, 0.4)
	tw.tween_callback(l.queue_free)
	p.get_tree().create_timer(1.6).timeout.connect(p.queue_free)


static func dmg_text(parent: Node, pos: Vector3, amount: float, col: Color = Color(1, 0.85, 0.3)) -> void:
	var l := Label3D.new()
	l.text = str(int(amount))
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	l.no_depth_test = true
	l.font_size = 72
	l.outline_size = 14
	l.modulate = col
	l.pixel_size = 0.006
	parent.add_child(l)
	l.global_position = pos
	var tw := l.create_tween().set_parallel(true)
	tw.tween_property(l, "position:y", l.position.y + 1.6, 0.8)
	tw.tween_property(l, "modulate:a", 0.0, 0.8)
	tw.chain().tween_callback(l.queue_free)


static func fog(parent: Node, pos: Vector3, size: Vector3, col: Color, density: float) -> FogVolume:
	var f := FogVolume.new()
	f.position = pos
	f.size = size
	var m := FogMaterial.new()
	m.density = density
	m.albedo = col
	f.material = m
	parent.add_child(f)
	return f
