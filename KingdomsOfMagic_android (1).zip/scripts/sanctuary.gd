class_name Sanctuary
extends RefCounted
## Santuario antiguo en las montañas: plataforma circular, columnas, altar, braseros y el jefe.

static func build(main: Node3D, rng: RandomNumberGenerator) -> Boss:
	var c := Vector3(Island.SANCT.x, Island.SANCT_Y, Island.SANCT.y)
	var root := Node3D.new()
	root.name = "SantuarioAncestral"
	root.position = c
	main.add_child(root)
	var stone := Color(0.52, 0.5, 0.56)
	var parts: Array = [
		Gfx.p_cyl(21.0, 22.0, 1.2, Vector3(0, -0.25, 0), stone, Vector3.ZERO, 48),
		Gfx.p_cyl(15.0, 15.0, 0.2, Vector3(0, 0.4, 0), Color(0.4, 0.38, 0.46), Vector3.ZERO, 48),
		Gfx.p_box(Vector3(6.0, 1.4, 3.0), Vector3(0, 0.9, -16.0), stone),
		Gfx.p_box(Vector3(2.2, 14.0, 2.2), Vector3(-5.5, 7.0, 20.0), stone),
		Gfx.p_box(Vector3(2.2, 14.0, 2.2), Vector3(5.5, 7.0, 20.0), stone),
		Gfx.p_box(Vector3(13.5, 1.8, 2.2), Vector3(0, 14.0, 20.0), stone, Vector3(0, 0, 2)),
	]
	Gfx.body_cyl(root, 21.5, 1.2, Vector3(0, -0.25, 0))
	Gfx.body_box(root, Vector3(6.0, 1.4, 3.0), Vector3(0, 0.9, -16.0))
	Gfx.body_box(root, Vector3(2.2, 14.0, 2.2), Vector3(-5.5, 7.0, 20.0))
	Gfx.body_box(root, Vector3(2.2, 14.0, 2.2), Vector3(5.5, 7.0, 20.0))
	for i in 12:
		var a := TAU * i / 12.0
		var pos := Vector3(cos(a) * 18.0, 0, sin(a) * 18.0)
		if pos.z > 14.0 and absf(pos.x) < 8.0:
			continue
		var broken := i % 4 == 1
		var h := 5.0 if broken else 10.0
		var tilt := Vector3(rng.randf_range(-5, 5), 0, rng.randf_range(-5, 5)) if broken else Vector3.ZERO
		parts.append(Gfx.p_cyl(0.8, 0.95, h, pos + Vector3(0, h * 0.5, 0), stone.lerp(Color(0.4, 0.5, 0.4), 0.3 if broken else 0.0), tilt, 12))
		if not broken:
			parts.append(Gfx.p_box(Vector3(2.0, 0.5, 2.0), pos + Vector3(0, 10.2, 0), stone))
		Gfx.body_cyl(root, 0.95, h, pos + Vector3(0, h * 0.5, 0))
	Gfx.add_mesh(root, Gfx.merge(parts))
	# círculo rúnico brillante
	Gfx.disc(root, 13.0, 0.02, Vector3(0, 0.52, 0), Color(0.6, 0.35, 1.0), 3.0)
	var inner := CylinderMesh.new()
	inner.top_radius = 12.5
	inner.bottom_radius = 12.5
	inner.height = 0.03
	inner.radial_segments = 48
	Gfx.add_mesh(root, inner, Vector3(0, 0.53, 0), Gfx.tinted(Color(0.14, 0.12, 0.2)))
	for i in 16:
		var a := TAU * i / 16.0
		var n := Gfx.glow_node(root, Gfx.box_mesh(Vector3(0.3, 0.04, 1.0)), Vector3(cos(a) * 11.0, 0.56, sin(a) * 11.0), Color(0.7, 0.45, 1.0), 4.0)
		n.rotation.y = -a
	# altar con cristal flotante
	var cone := CylinderMesh.new()
	cone.top_radius = 0.0
	cone.bottom_radius = 0.6
	cone.height = 1.6
	cone.radial_segments = 5
	var cr := Gfx.glow_node(root, cone, Vector3(0, 3.0, -16.0), Color(0.7, 0.4, 1.0), 4.0)
	Gfx.light(cr, Vector3.ZERO, Color(0.7, 0.4, 1.0), 2.5, 16.0)
	var tw := cr.create_tween().set_loops()
	tw.tween_property(cr, "rotation:y", TAU, 6.0).from(0.0)
	# braseros
	for p in [Vector3(-9, 0, -8), Vector3(9, 0, -8), Vector3(-9, 0, 8), Vector3(9, 0, 8)]:
		Gfx.add_mesh(root, Gfx.merge([Gfx.p_cyl(0.2, 0.3, 1.6, Vector3(0, 0.8, 0), stone, Vector3.ZERO, 8), Gfx.p_cyl(0.7, 0.35, 0.5, Vector3(0, 1.8, 0), Color(0.2, 0.2, 0.22), Vector3.ZERO, 10)]), p + Vector3(0, 0.5, 0))
		Gfx.light(root, p + Vector3(0, 3.0, 0), Color(0.8, 0.5, 1.0), 2.0, 14.0, true)
		var f := Fx.particles(Color(0.75, 0.5, 1.0), 24, 1.0, 0.4, Vector2(0.5, 1.4), 0.3, Vector3(0, 1.0, 0), 25.0)
		f.position = p + Vector3(0, 2.4, 0)
		root.add_child(f)
	Fx.fog(root, Vector3(0, 5, 0), Vector3(54, 14, 54), Color(0.6, 0.45, 0.9), 0.06)
	Island.keepout.append(Vector3(c.x, c.z, 32.0))
	Island.zones.append({"name": "Santuario del Guardián", "pos": Island.SANCT, "r": 30.0, "danger": 3})
	return Boss.create(main, c + Vector3(0, 0.45, -6.0))
