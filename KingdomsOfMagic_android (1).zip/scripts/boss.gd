class_name Boss
extends CharacterBody3D
## Aethros, Guardián Rúnico: despierta al acercarse; ataques: golpe sísmico, lluvia de meteoros y ráfaga rúnica.

signal defeated

var hp := 1800.0
var max_hp := 1800.0
var state := "dormant"
var atk_t := 2.5
var phase := 1
var busy := false
var player: Player
var visual: Node3D
var eye_mat: StandardMaterial3D
var eye_light: OmniLight3D
var plat_y := 0.0


static func create(parent: Node, pos: Vector3) -> Boss:
	var b := Boss.new()
	parent.add_child(b)
	b.global_position = pos
	b.plat_y = pos.y
	return b


func _ready() -> void:
	add_to_group("enemy")
	add_to_group("boss")
	collision_layer = 4
	collision_mask = 1
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 2.0
	cap.height = 7.4
	cs.shape = cap
	cs.position.y = 3.7
	add_child(cs)
	visual = Node3D.new()
	add_child(visual)
	var s := Color(0.28, 0.28, 0.33)
	var mo := Color(0.25, 0.4, 0.25)
	Gfx.add_mesh(visual, Gfx.merge([
		Gfx.p_box(Vector3(1.2, 2.2, 1.2), Vector3(-0.9, 1.1, 0), s),
		Gfx.p_box(Vector3(1.2, 2.2, 1.2), Vector3(0.9, 1.1, 0), s),
		Gfx.p_box(Vector3(3.4, 3.2, 2.2), Vector3(0, 3.9, 0), s),
		Gfx.p_box(Vector3(1.4, 1.2, 1.6), Vector3(-2.4, 5.4, 0), s),
		Gfx.p_box(Vector3(1.4, 1.2, 1.6), Vector3(2.4, 5.4, 0), s),
		Gfx.p_box(Vector3(1.0, 3.0, 1.0), Vector3(-2.6, 3.4, 0), s),
		Gfx.p_box(Vector3(1.0, 3.0, 1.0), Vector3(2.6, 3.4, 0), s),
		Gfx.p_box(Vector3(1.5, 1.5, 1.5), Vector3(-2.6, 1.3, 0), s),
		Gfx.p_box(Vector3(1.5, 1.5, 1.5), Vector3(2.6, 1.3, 0), s),
		Gfx.p_box(Vector3(1.6, 1.4, 1.6), Vector3(0, 6.2, -0.1), s),
		Gfx.p_cyl(0.0, 0.3, 1.6, Vector3(-0.7, 7.3, 0), s, Vector3(0, 0, 20), 6),
		Gfx.p_cyl(0.0, 0.3, 1.6, Vector3(0.7, 7.3, 0), s, Vector3(0, 0, -20), 6),
		Gfx.p_box(Vector3(1.2, 0.3, 0.8), Vector3(-2.4, 6.1, 0.1), mo),
		Gfx.p_box(Vector3(1.8, 0.3, 1.2), Vector3(0.3, 5.55, 0.3), mo),
	]))
	eye_mat = StandardMaterial3D.new()
	eye_mat.albedo_color = Color(1.0, 0.5, 0.2)
	eye_mat.emission_enabled = true
	eye_mat.emission = Color(1.0, 0.45, 0.15)
	eye_mat.emission_energy_multiplier = 0.0
	for x in [-0.4, 0.4]:
		var e := Gfx.add_mesh(visual, Gfx.box_mesh(Vector3(0.35, 0.2, 0.1)), Vector3(x, 6.3, -0.9), eye_mat)
		e.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	Gfx.glow_node(visual, Gfx.box_mesh(Vector3(1.6, 1.6, 0.1)), Vector3(0, 4.0, -1.12), Color(0.6, 0.35, 1.0), 3.0)
	for i in 4:
		var cone := CylinderMesh.new()
		cone.top_radius = 0.0
		cone.bottom_radius = 0.3
		cone.height = 1.6
		cone.radial_segments = 5
		var n := Gfx.glow_node(visual, cone, Vector3(-1.5 + i, 6.4, 1.0), Color(0.55, 0.4, 1.0), 3.0)
		n.rotation_degrees = Vector3(-25, 0, (i - 1.5) * 12.0)
	eye_light = Gfx.light(visual, Vector3(0, 6.3, -1.8), Color(1.0, 0.5, 0.2), 0.0, 22.0)


func _physics_process(delta: float) -> void:
	if player == null:
		player = get_tree().get_first_node_in_group("player")
		return
	if state == "dormant":
		if player.controls_enabled and player.global_position.distance_to(global_position) < 17.0 and player.hp > 0.0:
			_wake()
		return
	if state != "fight":
		return
	var to := player.global_position - global_position
	var flat := Vector3(to.x, 0, to.z)
	rotation.y = lerp_angle(rotation.y, atan2(-flat.x, -flat.z), 2.0 * delta)
	var want := Vector3.ZERO
	if not busy:
		atk_t -= delta
		if flat.length() > 9.0:
			want = flat.normalized() * 3.0
		if atk_t <= 0.0:
			_attack(flat.length())
	velocity.x = lerpf(velocity.x, want.x, 1.0 - exp(-6.0 * delta))
	velocity.z = lerpf(velocity.z, want.z, 1.0 - exp(-6.0 * delta))
	if not is_on_floor():
		velocity.y -= 24.0 * delta
	move_and_slide()


func _wake() -> void:
	state = "waking"
	var cam: CinematicCamera = get_tree().get_first_node_in_group("cam")
	var hud: HUD = get_tree().get_first_node_in_group("hud")
	player.controls_enabled = false
	hud.set_letterbox(true)
	await cam.fly_to(global_position + Vector3(0, 4, 24), global_position + Vector3(0, 5, 0), 2.2)
	cam.enable_dof(true)
	var tw := create_tween().set_parallel(true)
	tw.tween_property(eye_mat, "emission_energy_multiplier", 6.0, 1.5)
	tw.tween_property(eye_light, "light_energy", 6.0, 1.5)
	Fx.burst(get_parent(), global_position + Vector3(0, 3, 0), Color(0.7, 0.45, 1.0), 120, 0.6, 12.0)
	cam.shake(0.7)
	hud.say("Aethros, Guardián Rúnico: «¿Quién osa perturbar mi descanso milenario?»", 3.5)
	await get_tree().create_timer(3.0).timeout
	cam.enable_dof(false)
	hud.set_letterbox(false)
	hud.show_boss("Aethros, Guardián Rúnico", hp, max_hp)
	cam.begin_follow()
	player.controls_enabled = true
	state = "fight"


func _telegraph(pos: Vector3, radius: float, t: float) -> void:
	var m := CylinderMesh.new()
	m.top_radius = radius
	m.bottom_radius = radius
	m.height = 0.06
	m.radial_segments = 32
	var mi := MeshInstance3D.new()
	mi.mesh = m
	mi.material_override = Gfx.glow(Color(1.0, 0.2, 0.15), 3.0)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	get_parent().add_child(mi)
	mi.global_position = Vector3(pos.x, plat_y + 0.1, pos.z)
	mi.scale = Vector3(0.1, 1.0, 0.1)
	var tw := mi.create_tween()
	tw.tween_property(mi, "scale", Vector3.ONE, t)
	tw.tween_callback(mi.queue_free)


func _attack(dist: float) -> void:
	busy = true
	var r := randi() % 3
	if dist < 9.0 and r != 2:
		await _slam()
	elif r == 2 or (phase >= 2 and randf() < 0.5):
		await _meteors()
	else:
		await _bolts()
	atk_t = maxf(1.2, 3.2 - phase * 0.6)
	busy = false


func _slam() -> void:
	_telegraph(global_position, 9.0, 1.1)
	await get_tree().create_timer(1.1).timeout
	if state != "fight":
		return
	var cam := get_tree().get_first_node_in_group("cam")
	cam.shake(0.7)
	Fx.burst(get_parent(), global_position + Vector3(0, 0.5, 0), Color(1.0, 0.5, 0.3), 100, 0.6, 12.0)
	var d := Vector2(player.global_position.x - global_position.x, player.global_position.z - global_position.z).length()
	if d < 9.0 and player.global_position.y - global_position.y < 3.0:
		player.take_damage(28.0, self)
	await get_tree().create_timer(0.5).timeout


func _meteors() -> void:
	var n := 4 + phase * 2
	for i in n:
		var p := player.global_position + Vector3(randf_range(-8, 8), 0, randf_range(-8, 8))
		_telegraph(p, 2.4, 1.2)
		_drop(p)
		await get_tree().create_timer(0.25).timeout
	await get_tree().create_timer(1.4).timeout


func _drop(p: Vector3) -> void:
	await get_tree().create_timer(1.0).timeout
	if state != "fight":
		return
	Projectile.fire(get_parent(), Vector3(p.x, plat_y + 28.0, p.z), Vector3.DOWN, true, Color(1.0, 0.45, 0.15), 20.0, 34.0, 2.8, 0.7)


func _bolts() -> void:
	for v in 2:
		var from := global_position + Vector3(0, 4.5, 0)
		var base := (player.global_position + Vector3(0, 1.2, 0) - from).normalized()
		for k in 5:
			var d := base.rotated(Vector3.UP, deg_to_rad(-30 + k * 15))
			Projectile.fire(get_parent(), from + d * 2.0, d, true, Color(0.75, 0.4, 1.0), 14.0, 18.0, 0.0, 0.45)
		await get_tree().create_timer(0.8).timeout


func take_damage(amount: float, _src: Node = null) -> void:
	if state != "fight":
		return
	hp -= amount
	Fx.dmg_text(get_parent(), global_position + Vector3(randf_range(-1, 1), 8.0, 0), amount)
	var hud: HUD = get_tree().get_first_node_in_group("hud")
	hud.update_boss(maxf(hp, 0.0), max_hp)
	if phase == 1 and hp < max_hp * 0.66:
		phase = 2
		hud.say("¡Las runas del Guardián se encienden!", 3.0)
		get_tree().get_first_node_in_group("cam").shake(0.8)
	elif phase == 2 and hp < max_hp * 0.33:
		phase = 3
		hud.say("¡Aethros desata toda su furia ancestral!", 3.0)
		add_child(Fx.particles(Color(0.8, 0.5, 1.0), 80, 2.0, 0.6, Vector2(1.0, 3.0), 3.0, Vector3(0, 1, 0)))
		get_tree().get_first_node_in_group("cam").shake(0.8)
	if hp <= 0.0:
		_die()


func _die() -> void:
	state = "dead"
	var hud: HUD = get_tree().get_first_node_in_group("hud")
	var cam: CinematicCamera = get_tree().get_first_node_in_group("cam")
	hud.hide_boss()
	hud.say("¡Has derrotado a Aethros, el Guardián Rúnico!", 5.0)
	player.controls_enabled = false
	Fx.burst(get_parent(), global_position + Vector3(0, 4, 0), Color(0.8, 0.6, 1.0), 200, 0.8, 16.0)
	var tw := create_tween().set_parallel(true)
	tw.tween_property(visual, "scale:y", 0.2, 3.0)
	tw.tween_property(eye_light, "light_energy", 0.0, 1.0)
	defeated.emit()
	await cam.kill_cam(global_position)
	cam.begin_follow()
	player.controls_enabled = true
	queue_free()
