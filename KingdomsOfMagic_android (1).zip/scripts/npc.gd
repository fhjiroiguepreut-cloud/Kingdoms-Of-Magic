class_name NPC
extends Node3D
## Personaje no jugable con diálogo.

var npc_name := ""
var lines: Array = []
var idx := 0


static func spawn(parent: Node, pos: Vector3, yaw_deg: float, nm: String, dialog: Array, robe: Color, hat: Color) -> NPC:
	var n := NPC.new()
	n.npc_name = nm
	n.lines = dialog
	parent.add_child(n)
	n.global_position = pos
	n.rotation_degrees.y = yaw_deg
	n.add_child(CharacterRig.create(robe, Color(0.9, 0.75, 0.3), hat))
	var ap := CharacterRig.animator(n)
	ap.play("idle")
	Interactable.make(n, pos + Vector3(0, 1.0, 0), "Hablar con " + nm, n.talk, 3.2)
	return n


func talk(_p: Node) -> void:
	var hud := get_tree().get_first_node_in_group("hud")
	if hud:
		hud.say(npc_name + ": " + str(lines[idx % lines.size()]), 6.0)
	idx += 1
