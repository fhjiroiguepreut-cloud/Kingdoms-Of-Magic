class_name Vegetation
extends RefCounted
## Bosques con LOD por MultiMesh en chunks (malla detallada cerca, simple lejos), palmeras, rocas, hierba y flores.

const CH := 80.0


static func _pine(detail: bool) -> ArrayMesh:
	var bark := Color(0.3, 0.2, 0.12)
	var parts: Array = [Gfx.p_cyl(0.25, 0.42, 3.2, Vector3(0, 1.6, 0), bark, Vector3.ZERO, 7)]
	if detail:
		for k in 4:
			var r := 2.7 - k * 0.55
			parts.append(Gfx.p_cyl(0.0, r, 2.7, Vector3(0, 3.4 + k * 1.5, 0), Color(0.08, 0.28 + k * 0.03, 0.12), Vector3.ZERO, 9))
	else:
		parts.append(Gfx.p_cyl(0.0, 2.4, 8.0, Vector3(0, 6.0, 0), Color(0.1, 0.3, 0.13), Vector3.ZERO, 6))
	return Gfx.merge(parts)


static func _oak(detail: bool) -> ArrayMesh:
	var bark := Color(0.35, 0.24, 0.14)
	var parts: Array = [Gfx.p_cyl(0.3, 0.55, 3.6, Vector3(0, 1.8, 0), bark, Vector3.ZERO, 7)]
	if detail:
		parts.append(Gfx.p_sph(2.3, Vector3(0, 5.2, 0), Color(0.2, 0.45, 0.15), Vector3(1, 0.85, 1), 10))
		parts.append(Gfx.p_sph(1.6, Vector3(1.6, 4.6, 0.6), Color(0.26, 0.5, 0.18), Vector3.ONE, 8))
		parts.append(Gfx.p_sph(1.5, Vector3(-1.4, 4.8, -0.8), Color(0.18, 0.4, 0.14), Vector3.ONE, 8))
	else:
		parts.append(Gfx.p_sph(2.6, Vector3(0, 5.2, 0), Color(0.22, 0.46, 0.16), Vector3(1, 0.85, 1), 6))
	return Gfx.merge(parts)


static func _palm() -> ArrayMesh:
	var parts: Array = [
		Gfx.p_cyl(0.15, 0.24, 3.0, Vector3(0, 1.5, 0), Color(0.5, 0.38, 0.22), Vector3(0, 0, 4), 6),
		Gfx.p_cyl(0.12, 0.15, 2.4, Vector3(0.25, 4.0, 0), Color(0.5, 0.38, 0.22), Vector3(0, 0, 8), 6),
	]
	for i in 7:
		parts.append(Gfx.p_box(Vector3(0.35, 0.05, 2.8), Vector3(0.45, 5.2, 0), Color(0.2, 0.5, 0.18), Vector3(-25, i * 51.0, 0)))
	return Gfx.merge(parts)


static func _rock() -> ArrayMesh:
	var g := Color(0.45, 0.44, 0.43)
	return Gfx.merge([
		Gfx.p_sph(1.0, Vector3(0, 0.35, 0), g, Vector3(1, 0.7, 0.9), 7),
		Gfx.p_sph(0.7, Vector3(0.8, 0.2, 0.3), g.darkened(0.1), Vector3(1, 0.7, 1), 6),
	])


static func _grass() -> ArrayMesh:
	var parts: Array = []
	for i in 4:
		parts.append(Gfx.p_cyl(0.0, 0.07, 0.7, Vector3(0, 0.35, 0), Color(0.25 + i * 0.03, 0.5, 0.15), Vector3(randf_range(-18, 18), i * 90.0, randf_range(-18, 18)), 4))
	return Gfx.merge(parts)


static func _flower(col: Color) -> ArrayMesh:
	return Gfx.merge([
		Gfx.p_cyl(0.02, 0.02, 0.5, Vector3(0, 0.25, 0), Color(0.2, 0.5, 0.15), Vector3.ZERO, 4),
		Gfx.p_sph(0.12, Vector3(0, 0.55, 0), col, Vector3(1, 0.6, 1), 6),
	])


static func _add(buckets: Dictionary, t: Transform3D) -> void:
	var key := Vector2i(floori(t.origin.x / CH), floori(t.origin.z / CH))
	if not buckets.has(key):
		buckets[key] = []
	buckets[key].append(t)


static func _emit(parent: Node3D, mesh: Mesh, buckets: Dictionary, vis_begin: float, vis_end: float, shadows: bool) -> void:
	for key in buckets:
		var arr: Array = buckets[key]
		if arr.is_empty():
			continue
		var center := Vector3((key.x + 0.5) * CH, 0.0, (key.y + 0.5) * CH)
		var mm := MultiMesh.new()
		mm.transform_format = MultiMesh.TRANSFORM_3D
		mm.mesh = mesh
		mm.instance_count = arr.size()
		for i in arr.size():
			var t: Transform3D = arr[i]
			t.origin -= center
			mm.set_instance_transform(i, t)
		var mmi := MultiMeshInstance3D.new()
		mmi.multimesh = mm
		mmi.position = center
		mmi.material_override = Gfx.vc_mat()
		mmi.visibility_range_begin = vis_begin
		mmi.visibility_range_end = vis_end
		mmi.visibility_range_begin_margin = 25.0 if vis_begin > 0.0 else 0.0
		mmi.visibility_range_end_margin = 25.0
		mmi.visibility_range_fade_mode = GeometryInstance3D.VISIBILITY_RANGE_FADE_SELF
		if not shadows:
			mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		parent.add_child(mmi)


static func _tf(pos: Vector3, rng: RandomNumberGenerator, smin: float, smax: float) -> Transform3D:
	var s := rng.randf_range(smin, smax)
	var b := Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3(s, s * rng.randf_range(0.9, 1.15), s))
	return Transform3D(b, pos)


static func _yield() -> void:
	await (Engine.get_main_loop() as SceneTree).process_frame


static func build(parent: Node3D, rng: RandomNumberGenerator) -> void:
	var tk := 1.4 if OS.has_feature("mobile") else 1.0
	var gk := 2.0 if OS.has_feature("mobile") else 1.0
	var col := 0
	var root := Node3D.new()
	root.name = "Vegetacion"
	parent.add_child(root)
	var pine_n: Dictionary = {}
	var pine_f: Dictionary = {}
	var oak_n: Dictionary = {}
	var oak_f: Dictionary = {}
	var palms: Dictionary = {}
	var rocks: Dictionary = {}
	var grass: Dictionary = {}
	var fl_a: Dictionary = {}
	var fl_b: Dictionary = {}
	# árboles
	var x := -190.0
	while x < 190.0:
		var z := -190.0
		while z < 190.0:
			var px := x + rng.randf_range(-1.6, 1.6)
			var pz := z + rng.randf_range(-1.6, 1.6)
			z += 3.6 * tk
			var h := Island.height(px, pz)
			if h < 1.0 or h > 36.0:
				continue
			if Island.excluded(px, pz) or Island.path_d(px, pz) < 4.0:
				continue
			var sl := Island.slope(px, pz)
			var pos := Vector3(px, h - 0.2, pz)
			if h < 3.0:
				if h > 1.2 and rng.randf() < 0.12 and sl < 0.4:
					_add(palms, _tf(pos, rng, 0.9, 1.3))
				continue
			if sl > 0.6:
				continue
			if Island.forest_density(px, pz) > 0.46 and rng.randf() < 0.75:
				var t := _tf(pos, rng, 0.8, 1.5)
				if h > 18.0 or rng.randf() < 0.45:
					_add(pine_n, t)
					_add(pine_f, t)
				else:
					_add(oak_n, t)
					_add(oak_f, t)
		x += 3.6 * tk
		col += 1
		if col % 4 == 0:
			await _yield()
	_emit(root, _pine(true), pine_n, 0.0, 140.0, true)
	_emit(root, _pine(false), pine_f, 90.0, 700.0, false)
	_emit(root, _oak(true), oak_n, 0.0, 140.0, true)
	_emit(root, _oak(false), oak_f, 90.0, 700.0, false)
	_emit(root, _palm(), palms, 0.0, 300.0, true)
	# rocas
	x = -190.0
	while x < 190.0:
		var z := -190.0
		while z < 190.0:
			var px := x + rng.randf_range(-3.0, 3.0)
			var pz := z + rng.randf_range(-3.0, 3.0)
			z += 7.0
			var h := Island.height(px, pz)
			if h < 0.8 or Island.excluded(px, pz) or Island.path_d(px, pz) < 3.0:
				continue
			var sl := Island.slope(px, pz)
			if rng.randf() < (0.35 if sl > 0.5 else 0.05):
				_add(rocks, _tf(Vector3(px, h - 0.1, pz), rng, 0.6, 2.8))
		x += 7.0
	_emit(root, _rock(), rocks, 0.0, 400.0, true)
	# hierba y flores
	x = -170.0
	while x < 170.0:
		var z := -170.0
		while z < 170.0:
			var px := x + rng.randf_range(-1.1, 1.1)
			var pz := z + rng.randf_range(-1.1, 1.1)
			z += 2.2 * gk
			var h := Island.height(px, pz)
			if h < 2.8 or h > 18.0 or Island.excluded(px, pz) or Island.path_d(px, pz) < 3.5:
				continue
			if Island.slope(px, pz) > 0.5:
				continue
			var r := rng.randf()
			if r < 0.75:
				_add(grass, _tf(Vector3(px, h, pz), rng, 0.8, 1.6))
			elif r < 0.82:
				_add(fl_a, _tf(Vector3(px, h, pz), rng, 0.9, 1.3))
			elif r < 0.88:
				_add(fl_b, _tf(Vector3(px, h, pz), rng, 0.9, 1.3))
		x += 2.2 * gk
		col += 1
		if col % 4 == 0:
			await _yield()
	_emit(root, _grass(), grass, 0.0, 60.0, false)
	_emit(root, _flower(Color(0.95, 0.4, 0.65)), fl_a, 0.0, 60.0, false)
	_emit(root, _flower(Color(0.95, 0.9, 0.35)), fl_b, 0.0, 60.0, false)
