class_name CharacterRig
extends RefCounted
## Personaje humanoide articulado (mago) + animaciones idle/walk/run/cast generadas por código.

static func _pivot(parent: Node3D, nm: String, pos: Vector3) -> Node3D:
	var n := Node3D.new()
	n.name = nm
	n.position = pos
	parent.add_child(n)
	return n


static func _mesh(parent: Node3D, parts: Array) -> void:
	var mi := MeshInstance3D.new()
	mi.mesh = Gfx.merge(parts)
	mi.material_override = Gfx.vc_mat()
	parent.add_child(mi)


static func create(robe: Color, trim: Color, hat: Color) -> Node3D:
	var skin := Color(0.9, 0.72, 0.58)
	var dark := Color(0.14, 0.1, 0.1)
	var hair := Color(0.85, 0.85, 0.88)
	var rig := Node3D.new()
	rig.name = "Rig"
	var torso := _pivot(rig, "Torso", Vector3.ZERO)
	_mesh(torso, [
		Gfx.p_cyl(0.27, 0.42, 1.0, Vector3(0, 0.95, 0), robe),
		Gfx.p_cyl(0.29, 0.29, 0.08, Vector3(0, 1.08, 0), trim),
		Gfx.p_sph(0.3, Vector3(0, 1.4, 0), robe, Vector3(1.25, 0.5, 0.85)),
		Gfx.p_cyl(0.43, 0.43, 0.05, Vector3(0, 0.46, 0), trim),
	])
	var head := _pivot(torso, "Head", Vector3(0, 1.62, 0))
	_mesh(head, [
		Gfx.p_sph(0.17, Vector3.ZERO, skin),
		Gfx.p_sph(0.025, Vector3(-0.06, 0.02, -0.15), dark, Vector3.ONE, 6),
		Gfx.p_sph(0.025, Vector3(0.06, 0.02, -0.15), dark, Vector3.ONE, 6),
		Gfx.p_sph(0.18, Vector3(0, 0.03, 0.05), hair, Vector3(1, 0.9, 1)),
		Gfx.p_cyl(0.0, 0.1, 0.3, Vector3(0, -0.28, -0.08), hair),
		Gfx.p_cyl(0.34, 0.34, 0.03, Vector3(0, 0.12, 0), hat, Vector3.ZERO, 20),
		Gfx.p_cyl(0.0, 0.22, 0.52, Vector3(0, 0.4, 0), hat, Vector3.ZERO, 16),
		Gfx.p_cyl(0.225, 0.235, 0.06, Vector3(0, 0.16, 0), trim, Vector3.ZERO, 16),
	])
	var arm_l := _pivot(torso, "ArmL", Vector3(-0.36, 1.42, 0))
	_mesh(arm_l, [Gfx.p_cyl(0.075, 0.095, 0.5, Vector3(0, -0.25, 0), robe), Gfx.p_sph(0.07, Vector3(0, -0.53, 0), skin)])
	var arm_r := _pivot(torso, "ArmR", Vector3(0.36, 1.42, 0))
	_mesh(arm_r, [
		Gfx.p_cyl(0.075, 0.095, 0.5, Vector3(0, -0.25, 0), robe),
		Gfx.p_sph(0.07, Vector3(0, -0.53, 0), skin),
		Gfx.p_cyl(0.025, 0.03, 1.9, Vector3(0, -0.18, -0.04), Color(0.4, 0.26, 0.12)),
		Gfx.p_cyl(0.07, 0.04, 0.12, Vector3(0, 0.84, -0.04), trim),
	])
	var orb := Gfx.glow_node(arm_r, Gfx.sphere_mesh(0.1), Vector3(0, 0.95, -0.04), Color(0.45, 0.8, 1.0), 4.0)
	orb.name = "Orb"
	Gfx.light(orb, Vector3.ZERO, Color(0.5, 0.8, 1.0), 0.8, 5.0)
	var leg_l := _pivot(rig, "LegL", Vector3(-0.12, 0.5, 0))
	_mesh(leg_l, [Gfx.p_cyl(0.08, 0.07, 0.5, Vector3(0, -0.25, 0), dark), Gfx.p_box(Vector3(0.15, 0.08, 0.28), Vector3(0, -0.48, -0.05), dark)])
	var leg_r := _pivot(rig, "LegR", Vector3(0.12, 0.5, 0))
	_mesh(leg_r, [Gfx.p_cyl(0.08, 0.07, 0.5, Vector3(0, -0.25, 0), dark), Gfx.p_box(Vector3(0.15, 0.08, 0.28), Vector3(0, -0.48, -0.05), dark)])
	return rig


static func _sine(a: Animation, path: String, length: float, base: Vector3, amp: Vector3, phase: float = 0.0, harm: float = 1.0) -> void:
	var i := a.add_track(Animation.TYPE_VALUE)
	a.track_set_path(i, NodePath(path))
	a.track_set_interpolation_type(i, Animation.INTERPOLATION_CUBIC)
	var steps := 8
	for k in steps + 1:
		var t := float(k) / steps
		a.track_insert_key(i, t * length, base + amp * sin(t * TAU * harm + phase))


static func _keys(a: Animation, path: String, times: Array, vals: Array) -> void:
	var i := a.add_track(Animation.TYPE_VALUE)
	a.track_set_path(i, NodePath(path))
	a.track_set_interpolation_type(i, Animation.INTERPOLATION_CUBIC)
	for k in times.size():
		a.track_insert_key(i, times[k], vals[k])


static func _idle() -> Animation:
	var a := Animation.new()
	a.length = 3.0
	a.loop_mode = Animation.LOOP_LINEAR
	_sine(a, "Rig/Torso:position", 3.0, Vector3.ZERO, Vector3(0, 0.015, 0))
	_sine(a, "Rig/Torso/Head:rotation", 3.0, Vector3.ZERO, Vector3(0.03, 0.1, 0))
	_sine(a, "Rig/Torso/ArmL:rotation", 3.0, Vector3.ZERO, Vector3(0.05, 0, 0.04), 1.0)
	_sine(a, "Rig/Torso/ArmR:rotation", 3.0, Vector3.ZERO, Vector3(0.03, 0, -0.03), 2.0)
	return a


static func _walk(len_s: float, leg: float, arm: float, lean: float, bob: float) -> Animation:
	var a := Animation.new()
	a.length = len_s
	a.loop_mode = Animation.LOOP_LINEAR
	_sine(a, "Rig/LegL:rotation", len_s, Vector3.ZERO, Vector3(leg, 0, 0))
	_sine(a, "Rig/LegR:rotation", len_s, Vector3.ZERO, Vector3(leg, 0, 0), PI)
	_sine(a, "Rig/Torso/ArmL:rotation", len_s, Vector3.ZERO, Vector3(arm, 0, 0), PI)
	_sine(a, "Rig/Torso/ArmR:rotation", len_s, Vector3(0.1, 0, 0), Vector3(arm * 0.4, 0, 0))
	_sine(a, "Rig/Torso:position", len_s, Vector3.ZERO, Vector3(0, bob, 0), 0.0, 2.0)
	_sine(a, "Rig/Torso:rotation", len_s, Vector3(lean, 0, 0), Vector3(0, 0.1, 0))
	return a


static func _cast() -> Animation:
	var a := Animation.new()
	a.length = 0.7
	a.loop_mode = Animation.LOOP_NONE
	_keys(a, "Rig/Torso/ArmR:rotation", [0.0, 0.18, 0.4, 0.7], [Vector3.ZERO, Vector3(2.35, 0, 0.1), Vector3(2.1, 0, 0), Vector3.ZERO])
	_keys(a, "Rig/Torso/ArmL:rotation", [0.0, 0.2, 0.7], [Vector3.ZERO, Vector3(0.9, 0, -0.35), Vector3.ZERO])
	_keys(a, "Rig/Torso:rotation", [0.0, 0.18, 0.4, 0.7], [Vector3.ZERO, Vector3(-0.15, 0, 0), Vector3(-0.08, 0, 0), Vector3.ZERO])
	return a


static func animator(parent: Node) -> AnimationPlayer:
	var ap := AnimationPlayer.new()
	ap.name = "AnimationPlayer"
	parent.add_child(ap)
	var lib := AnimationLibrary.new()
	lib.add_animation("idle", _idle())
	lib.add_animation("walk", _walk(0.9, 0.65, 0.5, 0.0, 0.03))
	lib.add_animation("run", _walk(0.55, 1.0, 0.9, 0.25, 0.06))
	lib.add_animation("cast", _cast())
	ap.add_animation_library("", lib)
	return ap
