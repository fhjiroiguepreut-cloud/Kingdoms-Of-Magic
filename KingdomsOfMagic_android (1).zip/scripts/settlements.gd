class_name Settlements
extends RefCounted
## Pueblos medievales, aldeas costeras con muelle, puerto principal y puentes.

const WALLS := [Color(0.85, 0.78, 0.62), Color(0.8, 0.7, 0.55), Color(0.88, 0.85, 0.78), Color(0.75, 0.6, 0.45)]
const ROOFS := [Color(0.62, 0.22, 0.15), Color(0.45, 0.28, 0.16), Color(0.3, 0.38, 0.5), Color(0.7, 0.55, 0.25)]
const TIMBER := Color(0.25, 0.16, 0.09)
const STONE := Color(0.5, 0.48, 0.45)
const HAMLET_NAMES := ["Puerto Brisa", "Caleta Luna", "Bahía Escarcha", "Playa Ámbar", "Faro Viejo"]


static func build_all(parent: Node3D, rng: RandomNumberGenerator) -> void:
	for v in Island.villages:
		village(parent, v["pos"], v["name"], v["n"], rng)
	var angles := [12.0, 45.0, 168.0, 200.0, 335.0]
	for i in angles.size():
		hamlet(parent, angles[i], HAMLET_NAMES[i], rng)
	port(parent, rng)
	bridges(parent)


static func house(parent: Node, pos: Vector3, yaw: float, w: float, d: float, h: float, wall: Color, roof: Color) -> void:
	var root := Node3D.new()
	root.position = pos
	root.rotation.y = yaw
	parent.add_child(root)
	var b := 0.5
	var rh := d * 0.6 + 0.8
	var parts: Array = [
		Gfx.p_box(Vector3(w + 0.5, 1.8, d + 0.5), Vector3(0, -0.4, 0), STONE),
		Gfx.p_box(Vector3(w, h, d), Vector3(0, b + h * 0.5, 0), wall),
		Gfx.p_prism(Vector3(d + 1.8, rh, w + 1.4), Vector3(0, b + h + rh * 0.5, 0), roof, Vector3(0, 90, 0)),
		Gfx.p_box(Vector3(0.7, 2.2, 0.7), Vector3(w * 0.28, b + h + rh * 0.55, -d * 0.15), STONE),
		Gfx.p_box(Vector3(1.1, 2.0, 0.16), Vector3(0, b + 1.0, d * 0.5 + 0.04), TIMBER),
		Gfx.p_box(Vector3(1.6, 0.2, 0.6), Vector3(0, b + 0.1, d * 0.5 + 0.3), STONE),
		Gfx.p_box(Vector3(w + 0.1, 0.22, 0.22), Vector3(0, b + h * 0.55, d * 0.5 + 0.02), TIMBER),
		Gfx.p_box(Vector3(w + 0.1, 0.22, 0.22), Vector3(0, b + h * 0.55, -d * 0.5 - 0.02), TIMBER),
	]
	for sx in [-1.0, 1.0]:
		for sz in [-1.0, 1.0]:
			parts.append(Gfx.p_box(Vector3(0.28, h, 0.28), Vector3(sx * w * 0.5, b + h * 0.5, sz * d * 0.5), TIMBER))
	var mi := Gfx.add_mesh(root, Gfx.merge(parts))
	mi.name = "Casa"
	var wins: Array = []
	for sx in [-1.0, 1.0]:
		wins.append(Gfx.p_box(Vector3(0.9, 0.9, 0.1), Vector3(sx * w * 0.28, b + h * 0.55, d * 0.5 + 0.04), Color(1, 0.8, 0.5)))
		wins.append(Gfx.p_box(Vector3(0.9, 0.9, 0.1), Vector3(sx * w * 0.28, b + h * 0.55, -d * 0.5 - 0.04), Color(1, 0.8, 0.5)))
	Gfx.add_mesh(root, Gfx.merge(wins), Vector3.ZERO, Gfx.window_mat())
	Gfx.body_box(root, Vector3(w, h + 1.0, d), Vector3(0, (h + 1.0) * 0.5 + 0.0, 0))
	Gfx.light(root, Vector3(0, b + 2.6, d * 0.5 + 0.8), Color(1.0, 0.7, 0.4), 0.8, 7.0, true)


static func well(parent: Node, p: Vector3) -> void:
	var parts: Array = [
		Gfx.p_cyl(1.4, 1.5, 1.0, Vector3(0, 0.5, 0), STONE, Vector3.ZERO, 14),
		Gfx.p_cyl(1.0, 1.0, 0.05, Vector3(0, 1.0, 0), Color(0.05, 0.1, 0.18), Vector3.ZERO, 14),
		Gfx.p_box(Vector3(0.15, 2.6, 0.15), Vector3(-1.1, 1.8, 0), TIMBER),
		Gfx.p_box(Vector3(0.15, 2.6, 0.15), Vector3(1.1, 1.8, 0), TIMBER),
		Gfx.p_prism(Vector3(3.0, 1.0, 2.4), Vector3(0, 3.5, 0), Color(0.55, 0.2, 0.14), Vector3(0, 0, 0)),
	]
	Gfx.add_mesh(parent, Gfx.merge(parts), p)
	Gfx.body_cyl(parent, 1.5, 1.2, p + Vector3(0, 0.6, 0))


static func lamp_post(parent: Node, p: Vector3) -> void:
	var m := Gfx.merge([Gfx.p_cyl(0.06, 0.09, 3.2, Vector3(0, 1.6, 0), Color(0.15, 0.15, 0.17), Vector3.ZERO, 6)])
	Gfx.add_mesh(parent, m, p)
	Gfx.glow_node(parent, Gfx.sphere_mesh(0.18), p + Vector3(0, 3.3, 0), Color(1.0, 0.75, 0.35), 4.0)
	Gfx.light(parent, p + Vector3(0, 3.3, 0), Color(1.0, 0.72, 0.4), 1.2, 10.0, true)


static func stall(parent: Node, p: Vector3, yaw: float, col: Color) -> void:
	var root := Node3D.new()
	root.position = p
	root.rotation.y = yaw
	parent.add_child(root)
	var parts: Array = [
		Gfx.p_box(Vector3(3.0, 0.9, 1.2), Vector3(0, 0.45, 0), TIMBER),
		Gfx.p_box(Vector3(0.12, 2.6, 0.12), Vector3(-1.4, 1.3, -0.5), TIMBER),
		Gfx.p_box(Vector3(0.12, 2.6, 0.12), Vector3(1.4, 1.3, -0.5), TIMBER),
		Gfx.p_prism(Vector3(1.8, 0.7, 3.4), Vector3(0, 2.9, 0), col, Vector3(0, 90, 0)),
	]
	for i in 5:
		parts.append(Gfx.p_sph(0.16, Vector3(-1.1 + i * 0.55, 1.05, 0), Color(randf(), randf(), randf()).lightened(0.2), Vector3.ONE, 6))
	Gfx.add_mesh(root, Gfx.merge(parts))
	Gfx.body_box(root, Vector3(3.0, 1.0, 1.2), Vector3(0, 0.5, 0))


static func village(parent: Node3D, c: Vector2, vname: String, count: int, rng: RandomNumberGenerator) -> void:
	var root := Node3D.new()
	root.name = vname
	parent.add_child(root)
	var cy := Island.height(c.x, c.y)
	well(root, Vector3(c.x, cy, c.y))
	var placed: Array = []
	var tries := 0
	while placed.size() < count and tries < 500:
		tries += 1
		var a := rng.randf() * TAU
		var r := rng.randf_range(10.0, 34.0)
		var p := c + Vector2(cos(a), sin(a)) * r
		var h := Island.height(p.x, p.y)
		if h < 2.5 or Island.slope(p.x, p.y) > 0.22 or Island.excluded(p.x, p.y, 7.0):
			continue
		if p.distance_to(Island.LAKE) < 36.0 or absf(p.x - Island.river_x(p.y)) < 14.0:
			continue
		var ok := true
		for q in placed:
			if q.distance_to(p) < 11.0:
				ok = false
				break
		if not ok:
			continue
		placed.append(p)
		var dd := c - p
		var big := rng.randf() < 0.35
		house(root, Vector3(p.x, h, p.y), atan2(dd.x, dd.y), 8.0 if big else 6.0, 6.5 if big else 5.0, 5.5 if big else 3.8, WALLS[rng.randi() % WALLS.size()], ROOFS[rng.randi() % ROOFS.size()])
	for i in 4:
		var a := TAU * i / 4.0 + 0.4
		var lp := c + Vector2(cos(a), sin(a)) * 6.0
		lamp_post(root, Vector3(lp.x, Island.height(lp.x, lp.y), lp.y))
	for i in 2:
		var sp := c + Vector2(-5.0 + i * 10.0, 7.0)
		stall(root, Vector3(sp.x, Island.height(sp.x, sp.y), sp.y), PI * 0.0, ROOFS[i])
	var barrels: Array = []
	for i in 6:
		var bp := c + Vector2(rng.randf_range(-8, 8), rng.randf_range(-8, 8))
		var by := Island.height(bp.x, bp.y)
		barrels.append(Gfx.p_cyl(0.4, 0.4, 0.9, Vector3(bp.x, by + 0.45, bp.y), Color(0.45, 0.3, 0.15), Vector3.ZERO, 8))
		barrels.append(Gfx.p_box(Vector3(0.8, 0.8, 0.8), Vector3(bp.x + 1.0, by + 0.4, bp.y + 0.5), Color(0.55, 0.4, 0.22)))
	Gfx.add_mesh(root, Gfx.merge(barrels))
	var np := c + Vector2(2.5, 2.5)
	NPC.spawn(root, Vector3(np.x, Island.height(np.x, np.y), np.y), 200.0, "Aldeano de " + vname, [
		"Bienvenido a " + vname + ". Los lobos espectrales bajan de las montañas al anochecer.",
		"Si cruzas el bosque, ten cuidado con los fuegos fatuos. Disparan chispas.",
		"El Archimago de la Academia busca valientes para despertar al guardián del santuario.",
	], Color(0.45, 0.35, 0.2), Color(0.35, 0.25, 0.15))
	Island.keepout.append(Vector3(c.x, c.y, 40.0))
	Island.zones.append({"name": vname, "pos": c, "r": 38.0, "danger": 0})


static func dock(parent: Node, coast: Vector3, dir: Vector2, length: float, width: float) -> void:
	var yaw := atan2(dir.x, dir.y)
	var center := Vector3(coast.x, 0.9, coast.z) + Vector3(dir.x, 0, dir.y) * (length * 0.5 - 3.0)
	var sb := Gfx.solid(parent, Vector3(width, 0.3, length), center, Color(0.42, 0.28, 0.15))
	sb.rotation.y = yaw
	var posts: Array = []
	var k := 0.0
	while k < length:
		for s in [-1.0, 1.0]:
			var lp := Vector3(s * (width * 0.5 - 0.15), -1.0, k - length * 0.5)
			posts.append(Gfx.p_cyl(0.15, 0.15, 3.2, lp, Color(0.3, 0.2, 0.1), Vector3.ZERO, 6))
		k += 3.0
	Gfx.add_mesh(sb, Gfx.merge(posts))
	Gfx.glow_node(sb, Gfx.sphere_mesh(0.18), Vector3(width * 0.5 - 0.15, 2.2, length * 0.5 - 0.3), Color(1.0, 0.75, 0.35), 4.0)
	Gfx.light(sb, Vector3(width * 0.5 - 0.15, 2.4, length * 0.5 - 0.3), Color(1.0, 0.72, 0.4), 1.5, 12.0, true)


static func boat(parent: Node, pos: Vector3, yaw: float, s: float) -> Node3D:
	var n := Node3D.new()
	n.position = pos
	n.rotation.y = yaw
	n.scale = Vector3(s, s, s)
	parent.add_child(n)
	var wood := Color(0.4, 0.26, 0.14)
	var parts: Array = [
		Gfx.p_box(Vector3(1.8, 0.5, 4.6), Vector3(0, 0.3, 0), wood),
		Gfx.p_box(Vector3(0.15, 0.7, 4.6), Vector3(-0.95, 0.7, 0), wood),
		Gfx.p_box(Vector3(0.15, 0.7, 4.6), Vector3(0.95, 0.7, 0), wood),
		Gfx.p_box(Vector3(1.4, 0.7, 0.15), Vector3(0, 0.7, 2.3), wood),
		Gfx.p_box(Vector3(0.9, 0.5, 1.6), Vector3(0, 0.55, -2.8), wood, Vector3(0, 0, 0)),
		Gfx.p_cyl(0.06, 0.08, 4.0, Vector3(0, 2.5, 0.3), Color(0.3, 0.2, 0.1), Vector3.ZERO, 6),
		Gfx.p_box(Vector3(0.06, 2.6, 1.8), Vector3(0, 2.8, 0.9), Color(0.93, 0.9, 0.82)),
	]
	Gfx.add_mesh(n, Gfx.merge(parts))
	var tw := n.create_tween().set_loops()
	tw.tween_property(n, "position:y", pos.y + 0.1 * s, 2.0).set_trans(Tween.TRANS_SINE)
	tw.tween_property(n, "position:y", pos.y - 0.05 * s, 2.0).set_trans(Tween.TRANS_SINE)
	return n


static func hamlet(parent: Node3D, deg: float, hname: String, rng: RandomNumberGenerator) -> void:
	var ang := deg_to_rad(deg)
	var coast := Island.find_coast(ang)
	var dir := Vector2(cos(ang), sin(ang))
	var perp := Vector2(-dir.y, dir.x)
	var root := Node3D.new()
	root.name = hname
	parent.add_child(root)
	dock(root, coast, dir, 16.0, 3.0)
	boat(root, Vector3(coast.x + dir.x * 12.0 + perp.x * 3.5, 0.15, coast.z + dir.y * 12.0 + perp.y * 3.5), atan2(dir.x, dir.y), 1.0)
	var placed := 0
	var tries := 0
	var c2 := Vector2(coast.x, coast.z)
	while placed < 4 and tries < 200:
		tries += 1
		var p := c2 - dir * rng.randf_range(9.0, 26.0) + perp * rng.randf_range(-16.0, 16.0)
		var h := Island.height(p.x, p.y)
		if h < 1.8 or Island.slope(p.x, p.y) > 0.25 or Island.excluded(p.x, p.y, 8.0):
			continue
		house(root, Vector3(p.x, h, p.y), atan2(-dir.x, -dir.y), 5.5, 4.5, 3.4, WALLS[rng.randi() % 4], ROOFS[rng.randi() % 4])
		Island.keepout.append(Vector3(p.x, p.y, 8.0))
		placed += 1
	var net: Array = []
	for i in 3:
		var np := c2 - dir * 5.0 + perp * (-4.0 + i * 4.0)
		net.append(Gfx.p_box(Vector3(2.5, 0.06, 1.6), Vector3(np.x, Island.height(np.x, np.y) + 0.1, np.y), Color(0.7, 0.62, 0.4)))
	Gfx.add_mesh(root, Gfx.merge(net))
	var fp := c2 - dir * 8.0
	NPC.spawn(root, Vector3(fp.x, Island.height(fp.x, fp.y), fp.y), rad_to_deg(atan2(dir.x, dir.y)), "Pescador", [
		"El mar de Aetheria está en calma... pero más allá viven tormentas mágicas.",
		"Los barcos del puerto del sur zarparán hacia otros reinos algún día.",
	], Color(0.2, 0.4, 0.5), Color(0.6, 0.5, 0.3))
	Island.keepout.append(Vector3(c2.x, c2.y, 22.0))
	Island.zones.append({"name": "Aldea de " + hname, "pos": c2, "r": 26.0, "danger": 0})


static func port(parent: Node3D, rng: RandomNumberGenerator) -> void:
	var coast := Island.port
	var c2 := Vector2(coast.x, coast.z)
	var dir := c2.normalized()
	var perp := Vector2(-dir.y, dir.x)
	var root := Node3D.new()
	root.name = "PuertoAetheria"
	parent.add_child(root)
	dock(root, coast, dir, 30.0, 5.5)
	var ship_pos := Vector3(coast.x + dir.x * 26.0 + perp.x * 6.5, 0.2, coast.z + dir.y * 26.0 + perp.y * 6.5)
	boat(root, ship_pos, atan2(dir.x, dir.y) + PI * 0.5, 2.6)
	Interactable.make(root, Vector3(coast.x + dir.x * 24.0, 2.0, coast.z + dir.y * 24.0), "Consultar mapa de navegación", Callable(parent, "sail"), 6.0)
	var placed := 0
	var tries := 0
	while placed < 5 and tries < 300:
		tries += 1
		var p := c2 - dir * rng.randf_range(10.0, 30.0) + perp * rng.randf_range(-22.0, 22.0)
		var h := Island.height(p.x, p.y)
		if h < 1.8 or Island.slope(p.x, p.y) > 0.22 or Island.excluded(p.x, p.y, 9.0):
			continue
		house(root, Vector3(p.x, h, p.y), atan2(-dir.x, -dir.y), 8.0, 6.5, 5.0, WALLS[rng.randi() % 4], ROOFS[rng.randi() % 4])
		Island.keepout.append(Vector3(p.x, p.y, 9.0))
		placed += 1
	var sp := c2 - dir * 12.0
	NPC.spawn(root, Vector3(sp.x, Island.height(sp.x, sp.y), sp.y), rad_to_deg(atan2(dir.x, dir.y)), "Capitana Marla", [
		"Este es el Puerto de Aetheria. Ignar, Nivaria y Umbra te esperan al otro lado del mar.",
		"Mi barco aún no está listo. Necesito un Cristal Primordial para cruzar las tormentas mágicas.",
	], Color(0.15, 0.3, 0.45), Color(0.1, 0.2, 0.35))
	Island.keepout.append(Vector3(c2.x, c2.y, 30.0))
	Island.zones.append({"name": "Puerto de Aetheria", "pos": c2, "r": 32.0, "danger": 0})


static func bridges(parent: Node3D) -> void:
	for path in Island.paths:
		var prev := 0.0
		for i in path.size() - 1:
			var a: Vector2 = path[i]
			var b: Vector2 = path[i + 1]
			for s in 51:
				var p := a.lerp(b, s / 50.0)
				var side := p.x - Island.river_x(p.y)
				if p.y > -40.0 and prev != 0.0 and signf(side) != signf(prev) and absf(side) < 4.0:
					_bridge(parent, p, (b - a).normalized())
					return
				prev = side if side != 0.0 else prev


static func _bridge(parent: Node3D, p: Vector2, dir: Vector2) -> void:
	var half := 12.0
	var y := maxf(Island.height(p.x - dir.x * half, p.y - dir.y * half), Island.height(p.x + dir.x * half, p.y + dir.y * half)) + 0.3
	var root := Node3D.new()
	root.position = Vector3(p.x, y, p.y)
	root.rotation.y = atan2(dir.x, dir.y)
	parent.add_child(root)
	Gfx.solid(root, Vector3(3.6, 0.4, half * 2.0), Vector3.ZERO, Color(0.42, 0.28, 0.15))
	var rails: Array = []
	for s in [-1.0, 1.0]:
		rails.append(Gfx.p_box(Vector3(0.15, 0.15, half * 2.0), Vector3(s * 1.7, 1.0, 0), TIMBER))
		var k := -half
		while k <= half:
			rails.append(Gfx.p_box(Vector3(0.15, 1.1, 0.15), Vector3(s * 1.7, 0.55, k), TIMBER))
			k += 3.0
	Gfx.add_mesh(root, Gfx.merge(rails))
	Island.keepout.append(Vector3(p.x, p.y, 10.0))
