class_name Mine
extends RefCounted
## Entrada en la montaña + cámara subterránea de cristales mágicos (teletransporte).

static func build(main: Node3D, rng: RandomNumberGenerator) -> void:
	var e := Island.mine_entrance
	var origin: Vector3 = main.mine_origin
	# ---------- Entrada ----------
	var er := Node3D.new()
	er.name = "EntradaMinas"
	er.position = Vector3(e.x, e.y - 0.5, e.z + 1.0)
	main.add_child(er)
	var rock := Color(0.38, 0.36, 0.36)
	var arch := Gfx.merge([
		Gfx.p_box(Vector3(2.0, 8.0, 2.0), Vector3(-3.4, 3.5, 0), rock),
		Gfx.p_box(Vector3(2.0, 8.0, 2.0), Vector3(3.4, 3.5, 0), rock),
		Gfx.p_box(Vector3(9.4, 2.0, 2.4), Vector3(0, 8.0, 0), rock),
		Gfx.p_sph(3.2, Vector3(-7, 2, -1), rock, Vector3(1, 1, 0.8)),
		Gfx.p_sph(3.2, Vector3(7, 2, -1), rock, Vector3(1, 1, 0.8)),
		Gfx.p_sph(4.0, Vector3(0, 9.5, -2), rock, Vector3(1.6, 0.8, 1)),
		Gfx.p_box(Vector3(0.3, 6.0, 0.3), Vector3(-2.2, 3.0, 0.8), Color(0.3, 0.2, 0.1)),
		Gfx.p_box(Vector3(0.3, 6.0, 0.3), Vector3(2.2, 3.0, 0.8), Color(0.3, 0.2, 0.1)),
		Gfx.p_box(Vector3(4.8, 0.3, 0.3), Vector3(0, 6.1, 0.8), Color(0.3, 0.2, 0.1)),
	])
	Gfx.add_mesh(er, arch)
	Gfx.body_box(er, Vector3(2.0, 8.0, 2.0), Vector3(-3.4, 3.5, 0))
	Gfx.body_box(er, Vector3(2.0, 8.0, 2.0), Vector3(3.4, 3.5, 0))
	Gfx.solid(er, Vector3(5.4, 6.0, 0.6), Vector3(0, 3.0, -0.6), Color(0.02, 0.02, 0.04))
	for s in [-1.0, 1.0]:
		Gfx.glow_node(er, Gfx.sphere_mesh(0.2), Vector3(s * 2.2, 5.3, 1.1), Color(1.0, 0.75, 0.35), 4.0)
		Gfx.light(er, Vector3(s * 2.2, 5.3, 1.4), Color(1.0, 0.7, 0.35), 1.6, 12.0, true)
	var lbl := Label3D.new()
	lbl.text = "MINAS DE CRISTAL"
	lbl.font_size = 96
	lbl.pixel_size = 0.012
	lbl.outline_size = 16
	lbl.modulate = Color(0.95, 0.8, 0.4)
	lbl.position = Vector3(0, 10.2, 1.3)
	er.add_child(lbl)
	# vagoneta con cristales
	var cart := Gfx.merge([
		Gfx.p_box(Vector3(1.6, 0.8, 1.1), Vector3(0, 0.7, 0), Color(0.3, 0.3, 0.33)),
		Gfx.p_box(Vector3(0.2, 0.1, 7.0), Vector3(-0.6, 0.05, 0.5), Color(0.2, 0.2, 0.2)),
		Gfx.p_box(Vector3(0.2, 0.1, 7.0), Vector3(0.6, 0.05, 0.5), Color(0.2, 0.2, 0.2)),
	])
	Gfx.add_mesh(er, cart, Vector3(6.5, 0, 6.0))
	Gfx.glow_node(er, Gfx.sphere_mesh(0.3), Vector3(6.5, 1.3, 6.0), Color(0.4, 0.9, 1.0), 3.0)
	Island.keepout.append(Vector3(e.x, e.z, 10.0))
	Island.zones.append({"name": "Montañas del Eco", "pos": Vector2(30, -80), "r": 60.0, "danger": 2})
	Interactable.make(er, Vector3(e.x, e.y + 1.5, e.z + 4.0), "Entrar a las Minas de Cristal", Callable(main, "enter_mine"), 4.0)

	# ---------- Cámara subterránea ----------
	var r := Node3D.new()
	r.name = "MinasDeCristal"
	r.position = origin
	main.add_child(r)
	var dark := Color(0.2, 0.18, 0.24)
	Gfx.solid(r, Vector3(84, 2, 84), Vector3(0, -1, 0), Color(0.16, 0.14, 0.2))
	Gfx.solid(r, Vector3(88, 20, 2), Vector3(0, 9, -43), dark)
	Gfx.solid(r, Vector3(88, 20, 2), Vector3(0, 9, 43), dark)
	Gfx.solid(r, Vector3(2, 20, 88), Vector3(-43, 9, 0), dark)
	Gfx.solid(r, Vector3(2, 20, 88), Vector3(43, 9, 0), dark)
	Gfx.solid(r, Vector3(88, 2, 88), Vector3(0, 19, 0), dark)
	var rocks: Array = []
	for i in 40:
		var x := rng.randf_range(-38, 38)
		var z := rng.randf_range(-38, 38)
		var h := rng.randf_range(1.5, 5.0)
		var rad := rng.randf_range(0.5, 1.4)
		rocks.append(Gfx.p_cyl(0.0, rad, h, Vector3(x, h * 0.5, z), dark.lightened(0.1), Vector3.ZERO, 7))
		rocks.append(Gfx.p_cyl(rad, 0.0, h, Vector3(x + 3, 18.0 - h * 0.5, z - 2), dark.lightened(0.1), Vector3.ZERO, 7))
		if i < 12 and Vector2(x, z).length() > 8.0 and z < 28.0:
			Gfx.body_cyl(r, rad * 0.6, h, Vector3(x, h * 0.5, z))
	for i in 6:
		var px := -30.0 + i * 12.0
		var pz := rng.randf_range(-20, 10)
		rocks.append(Gfx.p_cyl(2.4, 2.8, 19.0, Vector3(px, 9.5, pz), dark, Vector3.ZERO, 9))
		Gfx.body_cyl(r, 2.8, 19.0, Vector3(px, 9.5, pz))
	Gfx.add_mesh(r, Gfx.merge(rocks))
	var cols := [Color(0.35, 0.9, 1.0), Color(0.9, 0.35, 1.0), Color(0.4, 1.0, 0.6)]
	for i in 22:
		var pos := Vector3(rng.randf_range(-36, 36), 0, rng.randf_range(-38, 26))
		if Vector2(pos.x, pos.z).length() < 5.0:
			continue
		var col: Color = cols[i % 3]
		var cl := Node3D.new()
		cl.position = pos
		r.add_child(cl)
		for k in 5:
			var cone := CylinderMesh.new()
			cone.top_radius = 0.0
			cone.bottom_radius = rng.randf_range(0.25, 0.5)
			cone.height = rng.randf_range(1.5, 3.5)
			cone.radial_segments = 6
			var n := Gfx.glow_node(cl, cone, Vector3(rng.randf_range(-0.6, 0.6), cone.height * 0.45, rng.randf_range(-0.6, 0.6)), col, 2.5)
			n.rotation_degrees = Vector3(rng.randf_range(-22, 22), rng.randf() * 360.0, rng.randf_range(-22, 22))
		Gfx.light(cl, Vector3(0, 1.5, 0), col, 1.6, 10.0)
		cl.add_child(Fx.particles(col, 8, 3.0, 0.12, Vector2(0.1, 0.4), 0.8, Vector3(0, 0.2, 0)))
		Interactable.make(cl, cl.global_position + Vector3(0, 1.0, 0), "Recoger cristal mágico", Callable(main, "collect_crystal"), 3.0)
	# lago de maná
	Gfx.disc(r, 9.0, 0.05, Vector3(14, 0.03, -14), Color(0.2, 0.55, 1.0), 2.0)
	Gfx.light(r, Vector3(14, 2.0, -14), Color(0.3, 0.6, 1.0), 2.0, 22.0)
	r.add_child(Fx.particles(Color(0.5, 0.8, 1.0), 40, 4.0, 0.18, Vector2(0.2, 0.7), 8.0, Vector3(0, 0.3, 0)))
	Fx.fog(r, Vector3(0, 6, 0), Vector3(80, 12, 80), Color(0.3, 0.4, 0.8), 0.04)
	# portal de salida
	var portal := Node3D.new()
	portal.position = Vector3(0, 0, 36)
	r.add_child(portal)
	Gfx.add_mesh(portal, Gfx.merge([
		Gfx.p_box(Vector3(1.0, 6.0, 1.0), Vector3(-2.5, 3, 0), rock),
		Gfx.p_box(Vector3(1.0, 6.0, 1.0), Vector3(2.5, 3, 0), rock),
		Gfx.p_box(Vector3(6.0, 1.0, 1.0), Vector3(0, 6.2, 0), rock),
	]))
	Gfx.glow_node(portal, Gfx.box_mesh(Vector3(4.0, 5.6, 0.1)), Vector3(0, 2.9, 0), Color(1.0, 0.85, 0.5), 2.5)
	Gfx.light(portal, Vector3(0, 3, 2), Color(1.0, 0.85, 0.5), 2.5, 16.0)
	Interactable.make(portal, portal.global_position + Vector3(0, 1.5, 1.0), "Salir de las minas", Callable(main, "exit_mine"), 4.0)
	Island.zones.append({"name": "Minas de Cristal", "pos": Vector2(origin.x, origin.z), "r": 60.0, "danger": 3})
