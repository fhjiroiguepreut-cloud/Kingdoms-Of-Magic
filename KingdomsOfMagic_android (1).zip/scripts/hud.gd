class_name HUD
extends CanvasLayer
## Interfaz: barras, hechizos, zonas, diálogos, jefe, pantalla de título, letterbox y viñeta.

const VIGNETTE := """
shader_type canvas_item;
void fragment() {
	vec2 uv = UV - 0.5;
	float v = smoothstep(0.35, 0.85, length(uv * vec2(1.0, 0.9)));
	COLOR = vec4(0.0, 0.0, 0.05, v * 0.55);
}
"""

var root: Control
var hp_bar: ProgressBar
var mana_bar: ProgressBar
var crystal_lbl: Label
var zone_lbl: Label
var zone_sub: Label
var prompt_lbl: Label
var msg_panel: PanelContainer
var msg_lbl: Label
var boss_root: Control
var boss_bar: ProgressBar
var boss_name: Label
var top_bar: ColorRect
var bot_bar: ColorRect
var fade_rect: ColorRect
var dmg_rect: ColorRect
var title_root: Control
var toast_lbl: Label
var spell_lbls: Array = []
var msg_token := 0
var toast_token := 0
var zone_tween: Tween


func _ready() -> void:
	add_to_group("hud")
	layer = 10
	root = Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)
	_build()


func _label(parent: Control, text: String, size: int, pos: Vector2, sz: Vector2, align: HorizontalAlignment = HORIZONTAL_ALIGNMENT_LEFT) -> Label:
	var l := Label.new()
	l.text = text
	l.position = pos
	l.size = sz
	l.horizontal_alignment = align
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", Color.WHITE)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	l.add_theme_constant_override("outline_size", 6)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(l)
	return l


func _bar(parent: Control, pos: Vector2, sz: Vector2, col: Color) -> ProgressBar:
	var b := ProgressBar.new()
	b.position = pos
	b.size = sz
	b.show_percentage = false
	b.max_value = 100.0
	b.value = 100.0
	var fill := StyleBoxFlat.new()
	fill.bg_color = col
	fill.set_corner_radius_all(6)
	var bg := StyleBoxFlat.new()
	bg.bg_color = Color(0, 0, 0, 0.55)
	bg.set_corner_radius_all(6)
	bg.set_border_width_all(2)
	bg.border_color = Color(1, 1, 1, 0.35)
	b.add_theme_stylebox_override("fill", fill)
	b.add_theme_stylebox_override("background", bg)
	b.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(b)
	return b


func _rect(col: Color, pos: Vector2, sz: Vector2) -> ColorRect:
	var r := ColorRect.new()
	r.color = col
	r.position = pos
	r.size = sz
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(r)
	return r


func _build() -> void:
	# viñeta
	var vig := _rect(Color.WHITE, Vector2.ZERO, Vector2(1920, 1080))
	var sh := Shader.new()
	sh.code = VIGNETTE
	var sm := ShaderMaterial.new()
	sm.shader = sh
	vig.material = sm
	dmg_rect = _rect(Color(0.8, 0.0, 0.0, 0.0), Vector2.ZERO, Vector2(1920, 1080))
	# barras
	_label(root, "VIDA", 18, Vector2(40, 30), Vector2(80, 24))
	hp_bar = _bar(root, Vector2(110, 30), Vector2(380, 26), Color(0.85, 0.15, 0.2))
	_label(root, "MANÁ", 18, Vector2(40, 66), Vector2(80, 24))
	mana_bar = _bar(root, Vector2(110, 66), Vector2(380, 26), Color(0.2, 0.5, 1.0))
	crystal_lbl = _label(root, "Cristales: 0", 24, Vector2(40, 104), Vector2(400, 34))
	# hechizos
	var names := ["[1] Bola Arcana", "[2] Rayo de Escarcha", "[3] Nova de Fuego"]
	for i in 3:
		var l := _label(root, names[i], 22, Vector2(40 + i * 280, 1020), Vector2(270, 34))
		spell_lbls.append(l)
	select_spell(0)
	# mira
	_rect(Color(1, 1, 1, 0.8), Vector2(958, 538), Vector2(4, 4))
	# zona
	zone_lbl = _label(root, "", 60, Vector2(0, 120), Vector2(1920, 80), HORIZONTAL_ALIGNMENT_CENTER)
	zone_sub = _label(root, "", 28, Vector2(0, 196), Vector2(1920, 40), HORIZONTAL_ALIGNMENT_CENTER)
	zone_lbl.modulate.a = 0.0
	zone_sub.modulate.a = 0.0
	prompt_lbl = _label(root, "", 30, Vector2(0, 780), Vector2(1920, 44), HORIZONTAL_ALIGNMENT_CENTER)
	toast_lbl = _label(root, "", 26, Vector2(0, 700), Vector2(1920, 40), HORIZONTAL_ALIGNMENT_CENTER)
	toast_lbl.add_theme_color_override("font_color", Color(1, 0.9, 0.5))
	# mensajes
	msg_panel = PanelContainer.new()
	msg_panel.position = Vector2(360, 850)
	msg_panel.size = Vector2(1200, 120)
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.05, 0.03, 0.12, 0.82)
	sb.set_corner_radius_all(12)
	sb.set_border_width_all(2)
	sb.border_color = Color(0.9, 0.75, 0.3, 0.9)
	sb.set_content_margin_all(18)
	msg_panel.add_theme_stylebox_override("panel", sb)
	msg_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	msg_lbl = Label.new()
	msg_lbl.add_theme_font_size_override("font_size", 26)
	msg_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	msg_lbl.custom_minimum_size = Vector2(1160, 0)
	msg_panel.add_child(msg_lbl)
	msg_panel.visible = false
	root.add_child(msg_panel)
	# jefe
	boss_root = Control.new()
	boss_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(boss_root)
	boss_name = _label(boss_root, "", 34, Vector2(0, 40), Vector2(1920, 44), HORIZONTAL_ALIGNMENT_CENTER)
	boss_bar = _bar(boss_root, Vector2(560, 90), Vector2(800, 22), Color(0.7, 0.2, 0.9))
	boss_root.visible = false
	# ayuda
	var help := _label(root, "WASD mover · Shift correr · Espacio saltar · Clic izq. hechizo · 1-3 cambiar · E interactuar · Esc ratón", 18, Vector2(960, 1040), Vector2(940, 26), HORIZONTAL_ALIGNMENT_RIGHT)
	help.modulate.a = 0.7
	# letterbox y fundido
	top_bar = _rect(Color.BLACK, Vector2(0, 0), Vector2(1920, 0))
	bot_bar = _rect(Color.BLACK, Vector2(0, 1080), Vector2(1920, 0))
	fade_rect = _rect(Color(0, 0, 0, 0), Vector2.ZERO, Vector2(1920, 1080))
	# título
	title_root = Control.new()
	title_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(title_root)
	var shade := ColorRect.new()
	shade.color = Color(0, 0, 0.08, 0.35)
	shade.size = Vector2(1920, 1080)
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	title_root.add_child(shade)
	var t := _label(title_root, "KINGDOMS OF MAGIC", 116, Vector2(0, 280), Vector2(1920, 140), HORIZONTAL_ALIGNMENT_CENTER)
	t.add_theme_color_override("font_color", Color(1.0, 0.85, 0.4))
	t.add_theme_constant_override("outline_size", 14)
	_label(title_root, "Isla de Aetheria — Reino de la Magia Antigua", 38, Vector2(0, 430), Vector2(1920, 50), HORIZONTAL_ALIGNMENT_CENTER)
	var go := _label(title_root, ("Toca la pantalla para comenzar" if OS.has_feature("mobile") else "Pulsa ENTER para comenzar"), 34, Vector2(0, 720), Vector2(1920, 50), HORIZONTAL_ALIGNMENT_CENTER)
	var tw := go.create_tween().set_loops()
	tw.tween_property(go, "modulate:a", 0.25, 0.9)
	tw.tween_property(go, "modulate:a", 1.0, 0.9)


# ---------- API ----------
func show_title(on: bool) -> void:
	title_root.visible = on


func set_hp(v: float, m: float) -> void:
	hp_bar.value = v / m * 100.0


func set_mana(v: float, m: float) -> void:
	mana_bar.value = v / m * 100.0


func set_crystals(n: int) -> void:
	crystal_lbl.text = "Cristales: %d" % n


func set_prompt(t: String) -> void:
	prompt_lbl.text = t


func select_spell(i: int) -> void:
	for k in spell_lbls.size():
		var l: Label = spell_lbls[k]
		l.add_theme_color_override("font_color", Color(1, 0.88, 0.4) if k == i else Color(1, 1, 1, 0.6))


func say(text: String, secs: float = 5.0) -> void:
	msg_token += 1
	var my := msg_token
	msg_lbl.text = text
	msg_panel.visible = true
	await get_tree().create_timer(secs).timeout
	if my == msg_token:
		msg_panel.visible = false


func toast(text: String) -> void:
	toast_token += 1
	var my := toast_token
	toast_lbl.text = text
	await get_tree().create_timer(2.5).timeout
	if my == toast_token:
		toast_lbl.text = ""


func announce(zone: String, danger: int) -> void:
	var subs := ["Zona segura", "Criaturas hostiles", "Zona muy peligrosa", "Zona mortal"]
	var cols := [Color(0.7, 1, 0.7), Color(1, 0.9, 0.5), Color(1, 0.55, 0.3), Color(1, 0.25, 0.25)]
	zone_lbl.text = zone
	zone_sub.text = subs[clampi(danger, 0, 3)]
	zone_sub.add_theme_color_override("font_color", cols[clampi(danger, 0, 3)])
	if zone_tween:
		zone_tween.kill()
	zone_tween = create_tween()
	zone_tween.tween_property(zone_lbl, "modulate:a", 1.0, 0.6)
	zone_tween.parallel().tween_property(zone_sub, "modulate:a", 1.0, 0.6)
	zone_tween.tween_interval(2.4)
	zone_tween.tween_property(zone_lbl, "modulate:a", 0.0, 1.2)
	zone_tween.parallel().tween_property(zone_sub, "modulate:a", 0.0, 1.2)


func flash_damage() -> void:
	dmg_rect.color.a = 0.4
	var tw := create_tween()
	tw.tween_property(dmg_rect, "color:a", 0.0, 0.5)


func fade(to_black: bool, t: float) -> void:
	var tw := create_tween()
	tw.tween_property(fade_rect, "color:a", 1.0 if to_black else 0.0, t)
	await tw.finished


func _set_bars(h: float) -> void:
	top_bar.size.y = h
	bot_bar.size.y = h
	bot_bar.position.y = 1080.0 - h


func set_letterbox(on: bool) -> void:
	var tw := create_tween()
	tw.tween_method(_set_bars, top_bar.size.y, 120.0 if on else 0.0, 0.8)


func show_boss(nm: String, v: float, m: float) -> void:
	boss_name.text = nm
	boss_bar.value = v / m * 100.0
	boss_root.visible = true


func update_boss(v: float, m: float) -> void:
	boss_bar.value = v / m * 100.0


func hide_boss() -> void:
	boss_root.visible = false
