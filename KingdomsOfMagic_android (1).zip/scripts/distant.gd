class_name Distant
extends RefCounted
## Siluetas de los otros reinos en el horizonte: Ignar, Nivaria y Umbra.

static func build(parent: Node3D) -> void:
	_island(parent, "Ignar", Vector3(-1000, 0, -750), Color(0.25, 0.12, 0.1), Color(1.0, 0.35, 0.1))
	_island(parent, "Nivaria", Vector3(1150, 0, -350), Color(0.85, 0.92, 1.0), Color(0.5, 0.85, 1.0))
	_island(parent, "Umbra", Vector3(350, 0, 1150), Color(0.14, 0.1, 0.2), Color(0.7, 0.3, 1.0))


static func _island(parent: Node3D, nm: String, pos: Vector3, rock: Color, glow: Color) -> void:
	var r := Node3D.new()
	r.name = "Reino_" + nm
	r.position = pos
	parent.add_child(r)
	var parts: Array = [
		Gfx.p_cyl(120.0, 220.0, 30.0, Vector3(0, -2, 0), rock.darkened(0.2), Vector3.ZERO, 16),
		Gfx.p_cyl(10.0, 120.0, 180.0, Vector3(0, 90, 0), rock, Vector3.ZERO, 12),
		Gfx.p_cyl(0.0, 60.0, 130.0, Vector3(110, 65, 40), rock, Vector3.ZERO, 8),
		Gfx.p_cyl(0.0, 50.0, 100.0, Vector3(-120, 50, -30), rock, Vector3.ZERO, 8),
	]
	Gfx.add_mesh(r, Gfx.merge(parts))
	var tip := Gfx.glow_node(r, Gfx.sphere_mesh(14.0), Vector3(0, 185, 0), glow, 5.0)
	Gfx.light(tip, Vector3.ZERO, glow, 8.0, 200.0)
