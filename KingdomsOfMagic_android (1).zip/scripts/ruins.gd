class_name Ruins
extends RefCounted
## Ruinas antiguas ocultas en el bosque, con runas, cofres de maná y criaturas.

static var sites: Array = []
const MOSS := Color(0.45, 0.52, 0.4)
const OLD := Color(0.6, 0.58, 0.55)


static func find_site(rng: RandomNumberGenerator, c: Vector2, r: float) -> Vector2:
	for k in 120:
		var p := c + Vector2(rng.randf_range(-r, r), rng.randf_range(-r, r))
		if Island.height(p.x, p.y) > 3.0 and Island.slope(p.x, p.y) < 0.25 and not Island.excluded(p.x, p.y, 12.0) and Island.path_d(p.x, p.y) > 8.0:
			return p
	return c


static func build_all(parent: Node3D, rng: RandomNumberGenerator) -> void:
	sites.clear()
	var centers := [Vector2(60, -25), Vector2(-50, -30), Vector2(115, 25)]
	var names := ["Ruinas del Eco", "Ruinas Susurrantes", "Ruinas del Alba Perdida"]
	for i in centers.size():
		var p := find_site(rng, centers[i], 25.0)
		sites.append(p)
		site(parent, p, rng, names[i])


static func site(parent: Node3D, c: Vector2, rng: RandomNumberGenerator, nm: String) -> void:
	var y := Island.height(c.x, c.y)
	var root := Node3D.new()
	root.name = nm
	root.position = Vector3(c.x, y, c.y)
	parent.add_child(root)
	var parts: Array = []
	for i in 8:
		var a := TAU * i / 8.0
		var pos := Vector3(cos(a) * 8.0, 0, sin(a) * 8.0)
		var broken := i % 3 != 0
		var h := rng.randf_range(2.0, 4.5) if broken else 7.0
		var tilt := Vector3(rng.randf_range(-6, 6), 0, rng.randf_range(-6, 6)) if broken else Vector3.ZERO
		parts.append(Gfx.p_cyl(0.7, 0.85, h, pos + Vector3(0, h * 0.5 - 0.3, 0), OLD.lerp(MOSS, rng.randf() * 0.7), tilt, 10))
		parts.append(Gfx.p_box(Vector3(1.4, 0.4, 1.4), pos + Vector3(0, -0.1, 0), OLD))
		if not broken:
			parts.append(Gfx.p_box(Vector3(1.6, 0.4, 1.6), pos + Vector3(0, 7.0, 0), OLD))
		Gfx.body_cyl(root, 0.85, h, pos + Vector3(0, h * 0.5 - 0.3, 0))
	# arco roto y muros
	parts.append(Gfx.p_box(Vector3(1.2, 6.0, 1.2), Vector3(-3, 3, -12), OLD))
	parts.append(Gfx.p_box(Vector3(1.2, 4.0, 1.2), Vector3(3, 2, -12), OLD))
	parts.append(Gfx.p_box(Vector3(7.5, 1.0, 1.2), Vector3(-0.5, 6.5, -12), MOSS, Vector3(0, 0, 8)))
	parts.append(Gfx.p_box(Vector3(6, 2.2, 0.9), Vector3(10, 1.1, -3), MOSS))
	parts.append(Gfx.p_box(Vector3(4, 1.4, 0.9), Vector3(-11, 0.7, 4), MOSS))
	parts.append(Gfx.p_cyl(0.7, 0.7, 5.0, Vector3(5, 0.7, 6), OLD, Vector3(0, 0, 80), 10))
	parts.append(Gfx.p_cyl(7.0, 7.4, 0.3, Vector3(0, -0.1, 0), Color(0.5, 0.5, 0.48), Vector3.ZERO, 24))
	Gfx.body_box(root, Vector3(1.2, 6.0, 1.2), Vector3(-3, 3, -12))
	Gfx.body_box(root, Vector3(1.2, 4.0, 1.2), Vector3(3, 2, -12))
	Gfx.body_box(root, Vector3(6, 2.2, 0.9), Vector3(10, 1.1, -3))
	Gfx.body_box(root, Vector3(4, 1.4, 0.9), Vector3(-11, 0.7, 4))
	Gfx.add_mesh(root, Gfx.merge(parts))
	# piedra rúnica central
	var stone := Gfx.merge([Gfx.p_box(Vector3(1.4, 3.0, 0.7), Vector3(0, 1.5, 0), Color(0.3, 0.3, 0.38))])
	Gfx.add_mesh(root, stone)
	Gfx.body_box(root, Vector3(1.4, 3.0, 0.7), Vector3(0, 1.5, 0))
	Gfx.glow_node(root, Gfx.box_mesh(Vector3(0.9, 1.8, 0.05)), Vector3(0, 1.6, -0.38), Color(0.6, 0.5, 1.0), 4.0)
	Gfx.glow_node(root, Gfx.box_mesh(Vector3(0.9, 1.8, 0.05)), Vector3(0, 1.6, 0.38), Color(0.6, 0.5, 1.0), 4.0)
	Gfx.light(root, Vector3(0, 2.2, -1.2), Color(0.6, 0.5, 1.0), 2.0, 14.0, true)
	root.add_child(Fx.particles(Color(0.7, 0.6, 1.0), 40, 3.0, 0.16, Vector2(0.3, 1.0), 3.0, Vector3(0, 0.4, 0)))
	Fx.fog(root, Vector3(0, 2, 0), Vector3(30, 6, 30), Color(0.6, 0.6, 0.9), 0.05)
	# cofre
	var chest := Gfx.merge([
		Gfx.p_box(Vector3(1.2, 0.7, 0.8), Vector3(0, 0.35, 0), Color(0.4, 0.25, 0.12)),
		Gfx.p_box(Vector3(1.25, 0.15, 0.85), Vector3(0, 0.78, 0), Color(0.55, 0.4, 0.15)),
		Gfx.p_box(Vector3(0.18, 0.25, 0.1), Vector3(0, 0.6, -0.42), Color(0.95, 0.8, 0.2)),
	])
	var cn := Node3D.new()
	cn.position = Vector3(-4.5, 0.1, 3.0)
	root.add_child(cn)
	Gfx.add_mesh(cn, chest)
	Gfx.light(cn, Vector3(0, 1.2, 0), Color(1.0, 0.85, 0.4), 0.8, 5.0)
	var it := Interactable.make(cn, cn.global_position + Vector3(0, 0.6, 0), "Abrir cofre antiguo", Callable(parent, "open_chest"), 3.0)
	it.set_meta("chest", cn)
	Island.keepout.append(Vector3(c.x, c.y, 14.0))
	Island.zones.append({"name": nm, "pos": c, "r": 24.0, "danger": 2})
