extends Node3D
## Kingdoms Of Magic — Isla de Aetheria. Orquesta el mundo, el jugador, la cámara y la interfaz.

var env: Environment
var sun: DirectionalLight3D
var player: Player
var cam: CinematicCamera
var hud: HUD
var rng := RandomNumberGenerator.new()
var crystals := 0
var kills := 0
var boss_defeated := false
var area := "outside"
var started := false
var mine_origin := Vector3(700.0, -80.0, 0.0)
var spawn_pos := Vector3(0.0, 9.5, 27.0)
var zone_name := ""
var zone_t := 0.0
var transitioning := false
var loaded := false
var load_layer: CanvasLayer
var load_lbl: Label
var load_start := 0
var load_stage := ""
var load_t := 0
var load_log := PackedStringArray()


func _ready() -> void:
	add_to_group("main")
	rng.seed = 2026
	load_start = Time.get_ticks_msec()
	_make_loading()
	await _step("Preparando el mundo...")
	_setup_input()
	Island.setup(1337)
	await _step("Generando el cielo y la luz...")
	var refs := EnvBuilder.build(self)
	env = refs["env"]
	sun = refs["sun"]
	await _step("Generando el terreno...")
	Terrain.build(self)
	Terrain.build_water(self)
	await _step("Construyendo la Academia Arcana...")
	Academy.build(self)
	load_log.append_array(Academy.timings)
	await _step("Construyendo pueblos y puertos...")
	Settlements.build_all(self, rng)
	await _step("Explorando ruinas, minas y santuario...")
	Ruins.build_all(self, rng)
	Mine.build(self, rng)
	var boss := Sanctuary.build(self, rng)
	boss.defeated.connect(_on_boss_defeated.bind(boss.global_position))
	await _step("Plantando bosques...")
	await Vegetation.build(self, rng)
	Distant.build(self)
	await _step("Despertando criaturas...")
	_spawn_enemies()
	_spawn_player_and_ui()
	var now := Time.get_ticks_msec()
	load_log.append("%s  %.1fs" % [load_stage, (now - load_t) / 1000.0])
	print("Carga total: %.1fs" % ((now - load_start) / 1000.0))
	load_layer.queue_free()
	loaded = true
	hud.say("Carga total: %.1fs\n%s" % [(now - load_start) / 1000.0, "\n".join(load_log)], 12.0)


func _make_loading() -> void:
	load_layer = CanvasLayer.new()
	load_layer.layer = 50
	add_child(load_layer)
	var bg := ColorRect.new()
	bg.color = Color(0.02, 0.02, 0.06)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	load_layer.add_child(bg)
	load_lbl = Label.new()
	load_lbl.set_anchors_preset(Control.PRESET_FULL_RECT)
	load_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	load_lbl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	load_lbl.add_theme_font_size_override("font_size", 44)
	load_layer.add_child(load_lbl)


func _step(text: String) -> void:
	var now := Time.get_ticks_msec()
	if load_stage != "":
		load_log.append("%s  %.1fs" % [load_stage, (now - load_t) / 1000.0])
	load_stage = text
	load_t = now
	load_lbl.text = "KINGDOMS OF MAGIC\n\n" + text + "\n\n" + "\n".join(load_log)
	await get_tree().process_frame
	await get_tree().process_frame


func _key(action: String, keys: Array) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	for k in keys:
		var ev := InputEventKey.new()
		ev.physical_keycode = k
		InputMap.action_add_event(action, ev)


func _setup_input() -> void:
	_key("move_forward", [KEY_W, KEY_UP])
	_key("move_back", [KEY_S, KEY_DOWN])
	_key("move_left", [KEY_A, KEY_LEFT])
	_key("move_right", [KEY_D, KEY_RIGHT])
	_key("jump", [KEY_SPACE])
	_key("sprint", [KEY_SHIFT])
	_key("interact", [KEY_E])
	_key("spell_1", [KEY_1])
	_key("spell_2", [KEY_2])
	_key("spell_3", [KEY_3])
	_key("start", [KEY_ENTER, KEY_KP_ENTER])
	if not InputMap.has_action("attack"):
		InputMap.add_action("attack")
		var mb := InputEventMouseButton.new()
		mb.button_index = MOUSE_BUTTON_LEFT
		InputMap.action_add_event("attack", mb)


func _spawn_player_and_ui() -> void:
	hud = HUD.new()
	add_child(hud)
	cam = CinematicCamera.new()
	add_child(cam)
	player = Player.new()
	add_child(player)
	player.global_position = spawn_pos
	player.cam = cam
	player.hud = hud
	player.main = self
	player.spawn_pos = spawn_pos
	cam.target = player
	cam.mode = CinematicCamera.Mode.ORBIT
	hud.show_title(true)
	if OS.has_feature("mobile"):
		var tc := TouchControls.new()
		tc.player = player
		tc.cam = cam
		tc.main = self
		add_child(tc)


func _spawn_enemies() -> void:
	var plans: Array = [
		["slime", Vector2(-30, 45), 55.0, 9], ["wisp", Vector2(-30, 45), 55.0, 4],
		["wolf", Vector2(30, -80), 60.0, 6], ["wolf", Vector2(-100, -20), 45.0, 3],
		["slime", Vector2(110, 25), 40.0, 4],
	]
	for s in Ruins.sites:
		plans.append(["wisp", s, 18.0, 3])
		plans.append(["wolf", s, 18.0, 2])
	for plan in plans:
		for i in plan[3]:
			for attempt in 40:
				var c: Vector2 = plan[1]
				var r: float = plan[2]
				var p := c + Vector2(rng.randf_range(-r, r), rng.randf_range(-r, r))
				var h := Island.height(p.x, p.y)
				if h > 3.0 and Island.slope(p.x, p.y) < 0.45 and not Island.excluded(p.x, p.y, 4.0):
					var e := Enemy.create(self, plan[0], Vector3(p.x, h + 1.0, p.y))
					e.died.connect(_on_enemy_died)
					break
	for i in 5:
		var gp := mine_origin + Vector3(rng.randf_range(-30, 30), 1.5, rng.randf_range(-30, 18))
		var g := Enemy.create(self, "golem", gp)
		g.died.connect(_on_enemy_died)


func _process(delta: float) -> void:
	if loaded and not started and Input.is_action_just_pressed("start"):
		start_game()
	if started and player != null:
		zone_t -= delta
		if zone_t <= 0.0:
			zone_t = 0.5
			_check_zone()


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED else Input.MOUSE_MODE_CAPTURED
	elif started and event is InputEventMouseButton and Input.mouse_mode != Input.MOUSE_MODE_CAPTURED and event.pressed:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func _check_zone() -> void:
	var best := ""
	var best_r := 1e9
	var danger := 0
	var pp := Vector2(player.global_position.x, player.global_position.z)
	for z in Island.zones:
		var inside_mine: bool = z["name"] == "Minas de Cristal"
		if inside_mine != (area == "inside"):
			continue
		var r: float = z["r"]
		if pp.distance_to(z["pos"]) < r and r < best_r:
			best = z["name"]
			best_r = r
			danger = z["danger"]
	if best != zone_name:
		zone_name = best
		if best != "":
			hud.announce(best, danger)


func start_game() -> void:
	started = true
	hud.show_title(false)
	hud.set_letterbox(true)
	var b := Basis.from_euler(Vector3(-0.2, 0.0, 0.0))
	var tp := player.global_position + Vector3(0, 1.55, 0) + b * Vector3(0.7, 0.0, 5.6)
	await cam.fly_to(tp, player.global_position + Vector3(0, 1.6, 0), 4.5)
	cam.begin_follow()
	hud.set_letterbox(false)
	player.controls_enabled = true
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	hud.say("Bienvenido a la Isla de Aetheria. Habla con el Archimago en la Academia Arcana.", 6.0)


func set_area(a: String) -> void:
	area = a
	var inside := a == "inside"
	sun.visible = not inside
	var tw := create_tween().set_parallel(true)
	tw.tween_property(env, "ambient_light_energy", 0.1 if inside else 0.9, 0.5)
	tw.tween_property(env, "volumetric_fog_density", 0.03 if inside else 0.011, 0.5)
	env.sdfgi_enabled = not inside
	env.ssr_enabled = not inside


func teleport(pos: Vector3, inside: bool, yaw: float) -> void:
	if transitioning:
		return
	transitioning = true
	player.controls_enabled = false
	await hud.fade(true, 0.5)
	player.global_position = pos
	player.velocity = Vector3.ZERO
	set_area("inside" if inside else "outside")
	cam.snap_behind(yaw)
	zone_name = ""
	await hud.fade(false, 0.6)
	player.controls_enabled = true
	transitioning = false


func enter_mine(_p: Node) -> void:
	teleport(mine_origin + Vector3(0, 1.0, 32.0), true, 0.0)


func exit_mine(_p: Node) -> void:
	var e := Island.mine_entrance
	teleport(Vector3(e.x, e.y + 1.5, e.z + 8.0), false, PI)


func collect_crystal(_p: Node) -> void:
	var it := player.near_inter
	if it == null:
		return
	crystals += 1
	hud.set_crystals(crystals)
	hud.toast("+1 cristal mágico")
	var node := it.get_parent()
	Fx.burst(self, node.global_position + Vector3(0, 1, 0), Color(0.5, 0.9, 1.0), 50, 0.4, 7.0)
	player.restore(20.0, 0.0)
	node.queue_free()


func open_chest(_p: Node) -> void:
	var it := player.near_inter
	if it == null:
		return
	it.enabled = false
	player.restore(60.0, 40.0)
	crystals += 2
	hud.set_crystals(crystals)
	Fx.burst(self, it.global_position + Vector3(0, 0.5, 0), Color(1.0, 0.85, 0.4), 60, 0.4, 7.0)
	hud.say("Has encontrado 2 cristales mágicos y una poción de maná.", 4.0)


func sail(_p: Node) -> void:
	if boss_defeated:
		hud.say("Mapa: Ignar (Reino del Fuego), Nivaria (Reino del Hielo) y Umbra (Reino de las Sombras). El Cristal Primordial brilla... ¡los barcos zarparán en la próxima actualización!", 9.0)
	else:
		hud.say("Mapa de navegación: Ignar, Nivaria y Umbra. Las tormentas mágicas bloquean el paso. Derrota al Guardián del santuario.", 7.0)


func _on_enemy_died(_e: Node) -> void:
	kills += 1


func _on_boss_defeated(pos: Vector3) -> void:
	boss_defeated = true
	var cone := CylinderMesh.new()
	cone.top_radius = 0.0
	cone.bottom_radius = 0.6
	cone.height = 1.8
	cone.radial_segments = 6
	var n := Gfx.glow_node(self, cone, pos + Vector3(0, 2.0, 0), Color(0.8, 0.5, 1.0), 5.0)
	Gfx.light(n, Vector3.ZERO, Color(0.8, 0.5, 1.0), 3.0, 18.0)
	var tw := n.create_tween().set_loops()
	tw.tween_property(n, "rotation:y", TAU, 5.0).from(0.0)
	Interactable.make(n, pos + Vector3(0, 2.0, 0), "Tomar el Cristal Primordial", Callable(self, "take_primordial"), 4.0)


func take_primordial(_p: Node) -> void:
	var it := player.near_inter
	if it:
		it.get_parent().queue_free()
	crystals += 10
	hud.set_crystals(crystals)
	hud.say("Has obtenido el Cristal Primordial. Los caminos hacia Ignar, Nivaria y Umbra se abrirán pronto...", 8.0)
