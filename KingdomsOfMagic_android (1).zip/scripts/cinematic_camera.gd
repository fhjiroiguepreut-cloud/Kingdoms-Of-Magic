class_name CinematicCamera
extends Camera3D
## Cámara cinematográfica: seguimiento suave sobre el hombro, colisión, FOV dinámico,
## sacudidas, hit-stop, DOF en escenas y vuelos de cámara.

enum Mode { FOLLOW, ORBIT, CINEMATIC }

var mode: Mode = Mode.ORBIT
var target: Node3D
var yaw := 0.0
var pitch := -0.22
var dist := 5.6
var shoulder := 0.7
var sens := 0.0028
var pos_k := 14.0
var rot_k := 18.0
var trauma := 0.0
var base_fov := 68.0
var fov_kick := 0.0
var sprint_fov := 0.0
var in_combat := 0.0
var orbit_center := Vector3(0, 12, 0)
var orbit_angle := 0.0
var orbit_radius := 115.0
var orbit_height := 95.0
var smooth_pivot := Vector3.ZERO
var attr: CameraAttributesPractical


func _ready() -> void:
	add_to_group("cam")
	fov = base_fov
	near = 0.1
	far = 4000.0
	attr = CameraAttributesPractical.new()
	attr.dof_blur_far_enabled = false
	attr.dof_blur_far_distance = 40.0
	attr.dof_blur_far_transition = 40.0
	attr.dof_blur_amount = 0.12
	attributes = attr
	current = true


func _unhandled_input(event: InputEvent) -> void:
	if mode == Mode.FOLLOW and event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		yaw -= event.relative.x * sens
		pitch = clampf(pitch - event.relative.y * sens, -1.2, 0.7)


func _process(delta: float) -> void:
	match mode:
		Mode.FOLLOW:
			_follow(delta)
		Mode.ORBIT:
			orbit_angle += delta * 0.05
			global_position = orbit_center + Vector3(cos(orbit_angle) * orbit_radius, orbit_height, sin(orbit_angle) * orbit_radius)
			look_at(orbit_center + Vector3(0, 6, 0))
	var tf := base_fov + sprint_fov + fov_kick - in_combat * 3.0
	fov = lerpf(fov, tf, 1.0 - exp(-8.0 * delta))
	fov_kick = lerpf(fov_kick, 0.0, 1.0 - exp(-6.0 * delta))
	trauma = maxf(0.0, trauma - delta * 1.4)
	var s := trauma * trauma
	h_offset = randf_range(-1.0, 1.0) * s * 0.35
	v_offset = randf_range(-1.0, 1.0) * s * 0.35


func _follow(delta: float) -> void:
	if target == null:
		return
	var pivot := target.global_position + Vector3(0, 1.55, 0)
	smooth_pivot = smooth_pivot.lerp(pivot, 1.0 - exp(-18.0 * delta))
	var b := Basis.from_euler(Vector3(pitch, yaw, 0.0))
	var desired := smooth_pivot + b * Vector3(shoulder, 0.0, dist + in_combat * 1.2)
	var q := PhysicsRayQueryParameters3D.create(smooth_pivot, desired, 1)
	var hit := get_world_3d().direct_space_state.intersect_ray(q)
	if not hit.is_empty():
		desired = hit["position"] + (smooth_pivot - desired).normalized() * 0.35
	global_position = global_position.lerp(desired, 1.0 - exp(-pos_k * delta))
	var des_q := Quaternion.from_euler(Vector3(pitch, yaw, 0.0))
	quaternion = quaternion.slerp(des_q, 1.0 - exp(-rot_k * delta))


# ---------- API ----------
func shake(a: float) -> void:
	trauma = minf(1.0, trauma + a)


func punch(f: float) -> void:
	fov_kick += f


func enable_dof(on: bool) -> void:
	attr.dof_blur_far_enabled = on


func hit_stop(duration: float, scale: float = 0.15) -> void:
	Engine.time_scale = scale
	await get_tree().create_timer(duration, true, false, true).timeout
	Engine.time_scale = 1.0


func aim_point() -> Vector3:
	var from := global_position
	var to := from - global_transform.basis.z * 120.0
	var q := PhysicsRayQueryParameters3D.create(from, to, 1 | 4)
	var hit := get_world_3d().direct_space_state.intersect_ray(q)
	return hit["position"] if not hit.is_empty() else to


func snap_behind(new_yaw: float) -> void:
	yaw = new_yaw
	pitch = -0.15
	if target:
		smooth_pivot = target.global_position + Vector3(0, 1.55, 0)
		var b := Basis.from_euler(Vector3(pitch, yaw, 0.0))
		global_position = smooth_pivot + b * Vector3(shoulder, 0.0, dist)
		quaternion = Quaternion.from_euler(Vector3(pitch, yaw, 0.0))


func begin_follow() -> void:
	yaw = rotation.y
	pitch = clampf(rotation.x, -1.2, 0.7)
	if target:
		smooth_pivot = target.global_position + Vector3(0, 1.55, 0)
	mode = Mode.FOLLOW
	pos_k = 4.0
	var tw := create_tween()
	tw.tween_property(self, "pos_k", 14.0, 1.6)


func fly_to(pos: Vector3, look: Vector3, dur: float) -> void:
	mode = Mode.CINEMATIC
	var p0 := global_position
	var l0 := global_position - global_transform.basis.z * 50.0
	var tw := create_tween().set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tw.tween_method(_fly_step.bind(p0, pos, l0, look), 0.0, 1.0, dur)
	await tw.finished


func _fly_step(t: float, p0: Vector3, p1: Vector3, l0: Vector3, l1: Vector3) -> void:
	global_position = p0.lerp(p1, t)
	var lp := l0.lerp(l1, t)
	if lp.distance_to(global_position) > 0.1:
		look_at(lp)


func kill_cam(center: Vector3) -> void:
	mode = Mode.CINEMATIC
	enable_dof(true)
	Engine.time_scale = 0.35
	get_tree().create_timer(1.5, true, false, true).timeout.connect(_restore_time)
	var a0 := atan2(global_position.z - center.z, global_position.x - center.x)
	var tw := create_tween().set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	tw.set_ignore_time_scale(true)
	tw.tween_method(_kill_step.bind(center, a0), 0.0, 1.0, 4.0)
	await tw.finished
	enable_dof(false)


func _restore_time() -> void:
	Engine.time_scale = 1.0


func _kill_step(t: float, center: Vector3, a0: float) -> void:
	var a := a0 + t * 2.2
	global_position = center + Vector3(cos(a) * 16.0, 5.0 + t * 3.0, sin(a) * 16.0)
	look_at(center + Vector3(0, 3, 0))
