# Kingdoms Of Magic — Isla de Aetheria (Godot 4.3+, Mobile / Android)

Abre la carpeta con Godot 4.3 o superior (renderer Forward+) y pulsa F5.
La primera carga genera el terreno por código (unos segundos).

## Controles
WASD mover · Shift correr · Espacio saltar · Clic izquierdo lanzar hechizo · 1/2/3 cambiar hechizo
E interactuar · Esc liberar/capturar ratón · Enter en la pantalla de título

## Qué incluye
- Terreno procedural con montañas, bosques, ríos, lago, playas y caminos; mar con shader (espuma, normales, fresnel).
- Academia Arcana en el centro: salón, mesas, bancos, estanterías, dormitorio, alquimia, chimenea, estrado, círculo mágico, plaza con fuente.
- 3 pueblos, 5 aldeas costeras con muelle y barco, puerto principal con barco grande y mapa de navegación, puente sobre el río.
- 3 ruinas ocultas en el bosque (runas, cofres de maná), minas de cristal subterráneas (golems), santuario con el primer jefe (Aethros, 3 fases).
- Criaturas: slime arcano, lobo espectral, fuego fatuo, golem de cristal. Zonas peligrosas anunciadas en pantalla.
- Siluetas de Ignar, Nivaria y Umbra en el horizonte (para viajes futuros en barco).

## Sistemas gráficos
PBR (triplanar + normal maps), Environment (cielo procedural, ACES, SSAO, SSIL, SSR, SDFGI, glow),
niebla volumétrica + FogVolumes, partículas GPU 3D, AnimationTree (idle/walk/run/cast),
LOD con visibility ranges (árboles detallados/simples por chunk), cámara cinematográfica
(seguimiento suave, colisión, FOV dinámico, sacudidas, hit-stop, DOF, vuelos y kill-cam).

## Rendimiento
Si va lento: en scripts/env_builder.gd desactiva `sdfgi_enabled`, `ssil_enabled` y `ssr_enabled`.


## Android
Controles táctiles: joystick flotante (izquierda), arrastrar a la derecha para mover la cámara, botones ATAQUE / SALTO / E / 1-2-3.
Renderer Mobile: sin SDFGI, SSAO, SSIL, SSR ni niebla volumétrica (se desactivan solos en móvil).
