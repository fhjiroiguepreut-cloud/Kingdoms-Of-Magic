class_name Academy
extends RefCounted
## Academia Arcana: edificio central con torres, salón con mesas, estanterías, dormitorio,
## alquimia, chimenea, estrado del archimago, círculo mágico y plaza con fuente.

const STONE := Color(0.64, 0.62, 0.6)
const WOOD := Color(0.36, 0.22, 0.11)
const WOOD2 := Color(0.52, 0.34, 0.18)
const SLATE := Color(0.2, 0.26, 0.42)
const RED := Color(0.55, 0.07, 0.1)
const GOLD := Color(0.92, 0.72, 0.22)
const CREAM := Color(0.92, 0.88, 0.78)


static var timings := PackedStringArray()


static func _tick(label: String, t0: int) -> int:
	var now := Time.get_ticks_msec()
	timings.append("   Academia/%s  %.2fs" % [label, (now - t0) / 1000.0])
	return now


static func _ps(col: Color, amount: int, life: float, size: float, vel: Vector2, radius: float, grav: Vector3, spread: float = 180.0) -> Node3D:
		return Fx.particles(col, amount, life, size, vel, radius, grav, spread)


static func _sub(parent: Node3D, text: String) -> void:
	## Actualiza la pantalla de carga y cede un fotograma para que no se congele.
	if parent.has_method("_sub"):
		await parent.call("_sub", text)


static func build(parent: Node3D) -> void:
	await _sub(parent, "inicio")
	var root := Node3D.new()
	root.name = "AcademiaArcana"
	root.position = Vector3(0, Island.ACADEMY_Y, 0)
	parent.add_child(root)
	Island.keepout.append(Vector3(0, 0, 44))
	Island.zones.append({"name": "Academia Arcana", "pos": Vector2(0, 0), "r": 42.0, "danger": 0})
	timings.clear()
	var t := Time.get_ticks_msec()
	await _sub(parent, "casco")
	_shell(root)
	t = _tick("casco", t)
	await _sub(parent, "torres")
	_towers(root)
	t = _tick("torres", t)
	await _sub(parent, "piso")
	_floor(root)
	t = _tick("piso", t)
	await _sub(parent, "muebles")
	_furniture(root)
	t = _tick("muebles", t)
	await _sub(parent, "dormitorio y alquimia")
	_dorm_and_alchemy(root)
	t = _tick("dormitorio", t)
	await _sub(parent, "circulo magico")
	_magic(root)
	t = _tick("circulo", t)
	await _sub(parent, "exterior y fuente")
	_exterior(root)
	t = _tick("exterior", t)
	await _sub(parent, "personajes")
	NPC.spawn(root, root.to_global(Vector3(0, 0.45, -6.5)), 180.0, "Archimago Elarion", [
		"Bienvenido a la Academia Arcana, joven aprendiz. Aetheria guarda la magia más antigua del mundo.",
		"Un guardián de piedra duerme en el santuario del norte. Solo un mago valiente podrá despertarlo.",
		"Las minas de cristal, al pie de las montañas, esconden maná puro... y a sus golems.",
		"Más allá del mar esperan Ignar, Nivaria y Umbra. Pero primero, domina tu magia.",
	], Color(0.2, 0.25, 0.7), Color(0.15, 0.2, 0.55))
	NPC.spawn(root, root.to_global(Vector3(4.5, 0, 8.0)), 200.0, "Aprendiz Lyra", [
		"¡Pulsa 1, 2 o 3 para cambiar de hechizo! La Nova de Fuego cuesta mucho maná.",
		"Dicen que hay ruinas ocultas entre los bosques, con cofres de maná.",
	], Color(0.7, 0.2, 0.35), Color(0.5, 0.15, 0.3))
	t = _tick("personajes", t)


static func _w(root: Node3D, cx: float, cz: float, sx: float, sz: float, h: float = 9.0, y0: float = 0.0) -> void:
	Gfx.solid(root, Vector3(sx, h, sz), Vector3(cx, y0 + h * 0.5, cz), STONE)


static func _shell(root: Node3D) -> void:
	Gfx.body_box(root, Vector3(34, 1.0, 26), Vector3(0, -0.45, 0))
	_w(root, 0, -10.5, 30, 1)
	_w(root, -14.5, 0, 1, 22)
	_w(root, 14.5, 0, 1, 22)
	_w(root, -8.5, 10.5, 12, 1)
	_w(root, 8.5, 10.5, 12, 1)
	_w(root, 0, 10.5, 5, 1, 2.5, 6.5)
	# techo
	var roof := Gfx.merge([
		Gfx.p_prism(Vector3(24, 6, 32), Vector3(0, 12, 0), SLATE, Vector3(0, 90, 0)),
		Gfx.p_box(Vector3(31, 0.5, 23), Vector3(0, 9.0, 0), STONE),
	])
	Gfx.add_mesh(root, roof)
	# torre central + faro
	var spire := Gfx.merge([
		Gfx.p_cyl(2.6, 3.6, 9.0, Vector3(0, 13.5, -2), STONE, Vector3.ZERO, 16),
		Gfx.p_cyl(3.0, 3.0, 0.5, Vector3(0, 18.2, -2), GOLD, Vector3.ZERO, 16),
		Gfx.p_cyl(0.0, 3.0, 7.0, Vector3(0, 22, -2), SLATE, Vector3.ZERO, 16),
	])
	Gfx.add_mesh(root, spire)
	var cone := CylinderMesh.new()
	cone.top_radius = 0.0
	cone.bottom_radius = 0.7
	cone.height = 2.2
	cone.radial_segments = 6
	var beacon := Gfx.glow_node(root, cone, Vector3(0, 27.5, -2), Color(0.5, 0.85, 1.0), 6.0)
	Gfx.light(beacon, Vector3.ZERO, Color(0.5, 0.8, 1.0), 3.0, 60.0)
	beacon.add_child(_ps(Color(0.6, 0.9, 1.0), 40, 3.0, 0.3, Vector2(0.5, 2.0), 1.0, Vector3(0, 0.5, 0)))
	var tw := beacon.create_tween().set_loops()
	tw.tween_property(beacon, "rotation:y", TAU, 10.0).from(0.0)
	# ventanas brillantes
	var wm := BoxMesh.new()
	for x in [-10.0, -5.0, 5.0, 10.0]:
		Gfx.glow_node(root, Gfx.box_mesh(Vector3(1.6, 3.2, 0.12)), Vector3(x, 5.0, 11.05), Color(1.0, 0.75, 0.4), 2.0)
		Gfx.glow_node(root, Gfx.box_mesh(Vector3(1.6, 3.2, 0.12)), Vector3(x, 5.0, -11.05), Color(1.0, 0.75, 0.4), 2.0)
	for z in [-5.0, 0.0, 5.0]:
		Gfx.glow_node(root, Gfx.box_mesh(Vector3(0.12, 3.2, 1.6)), Vector3(15.05, 5.0, z), Color(1.0, 0.75, 0.4), 2.0)
		Gfx.glow_node(root, Gfx.box_mesh(Vector3(0.12, 3.2, 1.6)), Vector3(-15.05, 5.0, z), Color(1.0, 0.75, 0.4), 2.0)
	wm = null


static func _towers(root: Node3D) -> void:
	for sx in [-1.0, 1.0]:
		for sz in [-1.0, 1.0]:
			var p := Vector3(sx * 14.5, 0, sz * 10.5)
			var t := Gfx.merge([
				Gfx.p_cyl(3.2, 3.4, 18.0, Vector3(0, 9, 0), STONE, Vector3.ZERO, 18),
				Gfx.p_cyl(3.7, 3.7, 0.6, Vector3(0, 18.2, 0), GOLD, Vector3.ZERO, 18),
				Gfx.p_cyl(0.0, 4.3, 7.0, Vector3(0, 22.0, 0), SLATE, Vector3.ZERO, 18),
			])
			Gfx.add_mesh(root, t, p)
			Gfx.body_cyl(root, 3.3, 18.0, p + Vector3(0, 9, 0))
			Gfx.glow_node(root, Gfx.box_mesh(Vector3(0.9, 2.2, 0.15)), p + Vector3(0, 12, sz * 3.3), Color(1.0, 0.75, 0.4), 2.0)
			Gfx.light(root, p + Vector3(0, 19, 0), Color(0.6, 0.8, 1.0), 1.2, 14.0)


static func _floor(root: Node3D) -> void:
	var tiles: Array = []
	var mobile := OS.has_feature("mobile")
	var nx := 7 if mobile else 14
	var nz := 5 if mobile else 10
	var ts := 4.0 if mobile else 2.0
	for ix in nx:
		for iz in nz:
			var col := Color(0.82, 0.78, 0.7) if (ix + iz) % 2 == 0 else Color(0.38, 0.38, 0.45)
			tiles.append(Gfx.p_box(Vector3(ts, 0.04, ts), Vector3(-14.0 + ts * 0.5 + ts * ix, 0.07, -10.0 + ts * 0.5 + ts * iz), col))
	tiles.append(Gfx.p_box(Vector3(4.4, 0.025, 19.4), Vector3(0, 0.09, 0), GOLD))
	tiles.append(Gfx.p_box(Vector3(4.0, 0.03, 19.0), Vector3(0, 0.11, 0), RED))
	Gfx.add_mesh(root, Gfx.merge(tiles))


static func _furniture(root: Node3D) -> void:
	var f: Array = []
	for sx in [-1.0, 1.0]:
		var x: float = sx * 6.2
		f.append(Gfx.p_box(Vector3(1.7, 0.14, 10.0), Vector3(x, 1.05, 1.0), WOOD2))
		for z in [-3.8, 0.0, 3.8, 5.6]:
			f.append(Gfx.p_box(Vector3(0.2, 1.0, 0.2), Vector3(x - 0.7, 0.5, z - 3.0), WOOD))
			f.append(Gfx.p_box(Vector3(0.2, 1.0, 0.2), Vector3(x + 0.7, 0.5, z - 3.0), WOOD))
		for bx in [-1.5, 1.5]:
			f.append(Gfx.p_box(Vector3(0.5, 0.1, 10.0), Vector3(x + bx, 0.55, 1.0), WOOD))
			for z in [-3.5, 1.0, 5.5]:
				f.append(Gfx.p_box(Vector3(0.4, 0.55, 0.12), Vector3(x + bx, 0.28, z), WOOD))
		# platos y jarras
		for z in [-3.0, -1.0, 2.0, 4.0]:
			f.append(Gfx.p_cyl(0.22, 0.2, 0.04, Vector3(x - 0.45, 1.14, z), CREAM))
			f.append(Gfx.p_cyl(0.22, 0.2, 0.04, Vector3(x + 0.45, 1.14, z), CREAM))
			f.append(Gfx.p_cyl(0.07, 0.06, 0.16, Vector3(x, 1.2, z + 0.4), GOLD))
		Gfx.body_box(root, Vector3(1.7, 1.1, 10.0), Vector3(x, 0.55, 1.0))
		for bx in [-1.5, 1.5]:
			Gfx.body_box(root, Vector3(0.5, 0.55, 10.0), Vector3(x + bx, 0.28, 1.0))
		for z in [-2.0, 1.0, 4.0]:
			var cm := CylinderMesh.new()
			cm.top_radius = 0.04
			cm.bottom_radius = 0.04
			cm.height = 0.25
			Gfx.add_mesh(root, cm, Vector3(x, 1.25, z), Gfx.tinted(CREAM))
			Gfx.glow_node(root, Gfx.sphere_mesh(0.05), Vector3(x, 1.43, z), Color(1.0, 0.7, 0.3), 5.0)
			Gfx.light(root, Vector3(x, 1.7, z), Color(1.0, 0.7, 0.4), 0.7, 6.0, true)
	# estanterías
	var palette := [Color(0.5, 0.1, 0.1), Color(0.1, 0.3, 0.5), Color(0.15, 0.4, 0.2), Color(0.5, 0.35, 0.1), Color(0.35, 0.15, 0.45), Color(0.6, 0.55, 0.45)]
	var rng := RandomNumberGenerator.new()
	rng.seed = 77
	for x in [-11.0, -6.2, 6.2, 11.0]:
		f.append(Gfx.p_box(Vector3(5.0, 7.0, 0.15), Vector3(x, 3.5, -9.9), WOOD))
		f.append(Gfx.p_box(Vector3(0.18, 7.0, 0.9), Vector3(x - 2.5, 3.5, -9.5), WOOD))
		f.append(Gfx.p_box(Vector3(0.18, 7.0, 0.9), Vector3(x + 2.5, 3.5, -9.5), WOOD))
		for row in 5:
			f.append(Gfx.p_box(Vector3(5.0, 0.12, 0.9), Vector3(x, 0.3 + row * 1.5, -9.5), WOOD2))
			var cx := x - 2.25
			for k in (8 if OS.has_feature("mobile") else 16):
				var h := rng.randf_range(0.8, 1.2)
				var w := rng.randf_range(0.15, 0.22) * (2.1 if OS.has_feature("mobile") else 1.0)
				f.append(Gfx.p_box(Vector3(w, h, 0.6), Vector3(cx + w * 0.5, 0.36 + row * 1.5 + h * 0.5, -9.55), palette[rng.randi() % palette.size()]))
				cx += w + 0.04
		Gfx.body_box(root, Vector3(5.0, 7.0, 1.0), Vector3(x, 3.5, -9.5))
	# estrado del archimago
	Gfx.solid(root, Vector3(12, 0.15, 6.6), Vector3(0, 0.075, -7.0), STONE)
	Gfx.solid(root, Vector3(12, 0.3, 5.8), Vector3(0, 0.15, -7.4), STONE)
	Gfx.solid(root, Vector3(12, 0.45, 5.0), Vector3(0, 0.225, -7.8), Color(0.55, 0.52, 0.5))
	f.append(Gfx.p_box(Vector3(3.2, 0.2, 1.2), Vector3(0, 1.45, -8.7), WOOD2))
	f.append(Gfx.p_box(Vector3(3.0, 1.0, 1.0), Vector3(0, 0.95, -8.7), WOOD))
	f.append(Gfx.p_box(Vector3(1.4, 2.8, 0.2), Vector3(0, 1.9, -9.7), WOOD))
	f.append(Gfx.p_box(Vector3(1.0, 0.15, 0.9), Vector3(0, 0.95, -9.2), RED))
	Gfx.body_box(root, Vector3(3.2, 1.4, 1.2), Vector3(0, 1.15, -8.7))
	# columnas interiores
	for sx in [-10.0, 10.0]:
		for z in [-6.0, -2.0, 2.0, 6.0]:
			f.append(Gfx.p_cyl(0.55, 0.65, 9.0, Vector3(sx, 4.5, z), STONE, Vector3.ZERO, 14))
			f.append(Gfx.p_cyl(0.8, 0.8, 0.4, Vector3(sx, 0.2, z), GOLD, Vector3.ZERO, 14))
			f.append(Gfx.p_cyl(0.8, 0.8, 0.4, Vector3(sx, 8.8, z), GOLD, Vector3.ZERO, 14))
			Gfx.body_cyl(root, 0.65, 9.0, Vector3(sx, 4.5, z))
	# estandartes
	for x in [-3.5, 3.5, -8.5, 8.5]:
		f.append(Gfx.p_box(Vector3(1.6, 5.5, 0.08), Vector3(x, 5.3, -9.88), RED))
		f.append(Gfx.p_box(Vector3(1.6, 0.25, 0.1), Vector3(x, 8.0, -9.86), GOLD))
		f.append(Gfx.p_box(Vector3(0.18, 4.0, 0.1), Vector3(x, 5.0, -9.84), GOLD))
	# lámpara de araña
	f.append(Gfx.p_cyl(2.2, 2.2, 0.2, Vector3(0, 7.2, 0), GOLD, Vector3.ZERO, 24))
	f.append(Gfx.p_cyl(0.04, 0.04, 2.0, Vector3(0, 8.3, 0), GOLD))
	for i in 8:
		var a := TAU * i / 8.0
		Gfx.glow_node(root, Gfx.sphere_mesh(0.09), Vector3(cos(a) * 2.0, 7.55, sin(a) * 2.0), Color(1.0, 0.7, 0.3), 5.0)
	Gfx.light(root, Vector3(0, 6.6, 0), Color(1.0, 0.82, 0.55), 3.0, 26.0, false, true)
	# chimenea
	f.append(Gfx.p_box(Vector3(1.6, 4.2, 4.4), Vector3(-13.2, 2.1, -2.0), Color(0.45, 0.43, 0.42)))
	f.append(Gfx.p_box(Vector3(2.0, 0.25, 5.0), Vector3(-13.0, 2.5, -2.0), WOOD))
	Gfx.body_box(root, Vector3(1.6, 4.2, 4.4), Vector3(-13.2, 2.1, -2.0))
	Gfx.glow_node(root, Gfx.box_mesh(Vector3(0.2, 1.4, 2.4)), Vector3(-12.35, 0.9, -2.0), Color(1.0, 0.45, 0.1), 4.0)
	Gfx.light(root, Vector3(-11.0, 1.4, -2.0), Color(1.0, 0.55, 0.25), 3.5, 15.0, true)
	var fire: Node3D = _ps(Color(1.0, 0.55, 0.2), 30, 1.0, 0.35, Vector2(0.5, 1.5), 0.4, Vector3(0, 1.0, 0), 30.0)
	fire.position = Vector3(-12.2, 0.6, -2.0)
	root.add_child(fire)
	Gfx.add_mesh(root, Gfx.merge(f))


static func _dorm_and_alchemy(root: Node3D) -> void:
	var p: Array = []
	var colors := [Color(0.5, 0.1, 0.12), Color(0.1, 0.3, 0.5), Color(0.15, 0.4, 0.25), Color(0.5, 0.35, 0.1)]
	for i in 4:
		var z := -7.5 + i * 4.0
		var x := 12.6
		p.append(Gfx.p_box(Vector3(2.2, 0.5, 3.6), Vector3(x, 0.3, z), WOOD))
		p.append(Gfx.p_box(Vector3(2.0, 0.25, 3.4), Vector3(x, 0.62, z), Color(0.95, 0.93, 0.88)))
		p.append(Gfx.p_box(Vector3(2.05, 0.28, 2.0), Vector3(x, 0.68, z + 0.7), colors[i]))
		p.append(Gfx.p_box(Vector3(1.0, 0.2, 0.6), Vector3(x, 0.85, z - 1.3), Color(0.95, 0.95, 1.0)))
		p.append(Gfx.p_box(Vector3(2.2, 1.3, 0.15), Vector3(x, 0.9, z - 1.8), WOOD))
		Gfx.body_box(root, Vector3(2.2, 0.8, 3.6), Vector3(x, 0.4, z))
	p.append(Gfx.p_box(Vector3(1.2, 3.6, 2.4), Vector3(13.3, 1.8, 8.6), WOOD))
	p.append(Gfx.p_box(Vector3(1.0, 0.8, 1.6), Vector3(12.2, 0.4, 9.6), WOOD2))
	p.append(Gfx.p_box(Vector3(0.1, 0.2, 0.3), Vector3(11.7, 0.7, 9.6), GOLD))
	Gfx.body_box(root, Vector3(1.2, 3.6, 2.4), Vector3(13.3, 1.8, 8.6))
	# rincón de alquimia
	p.append(Gfx.p_box(Vector3(3.2, 0.15, 1.4), Vector3(-11.0, 1.0, 7.4), WOOD2))
	p.append(Gfx.p_box(Vector3(3.0, 0.9, 1.2), Vector3(-11.0, 0.5, 7.4), WOOD))
	Gfx.body_box(root, Vector3(3.2, 1.1, 1.4), Vector3(-11.0, 0.55, 7.4))
	var pot_cols := [Color(0.3, 1.0, 0.5), Color(0.9, 0.3, 1.0), Color(0.3, 0.7, 1.0), Color(1.0, 0.5, 0.2), Color(1.0, 0.9, 0.3)]
	for i in 5:
		Gfx.glow_node(root, Gfx.sphere_mesh(0.14), Vector3(-12.2 + i * 0.55, 1.28, 7.4), pot_cols[i], 2.5)
		p.append(Gfx.p_cyl(0.05, 0.05, 0.14, Vector3(-12.2 + i * 0.55, 1.5, 7.4), GOLD))
	p.append(Gfx.p_sph(0.8, Vector3(-8.2, 0.7, 8.0), Color(0.1, 0.1, 0.12), Vector3(1, 0.85, 1)))
	p.append(Gfx.p_cyl(0.82, 0.82, 0.12, Vector3(-8.2, 1.15, 8.0), Color(0.15, 0.15, 0.18)))
	Gfx.body_cyl(root, 0.85, 1.2, Vector3(-8.2, 0.6, 8.0))
	Gfx.disc(root, 0.65, 0.04, Vector3(-8.2, 1.2, 8.0), Color(0.3, 1.0, 0.5), 3.0)
	Gfx.light(root, Vector3(-8.2, 1.8, 8.0), Color(0.3, 1.0, 0.5), 1.4, 8.0)
	root.add_child(_bubbles(Vector3(-8.2, 1.3, 8.0)))
	for i in 6:
		p.append(Gfx.p_box(Vector3(0.1, 0.9, 0.1), Vector3(-13.0, 6.0 - 0.0, 3.0 + i * 0.6), Color(0.3, 0.45, 0.2)))
	Gfx.add_mesh(root, Gfx.merge(p))


static func _bubbles(pos: Vector3) -> Node3D:
	var b: Node3D = _ps(Color(0.4, 1.0, 0.6), 18, 1.4, 0.2, Vector2(0.4, 1.0), 0.45, Vector3(0, 0.2, 0), 25.0)
	b.position = pos
	return b


static func _magic(root: Node3D) -> void:
	var c := Vector3(0, 0, 4.5)
	Gfx.disc(root, 3.3, 0.03, c + Vector3(0, 0.12, 0), Color(0.4, 0.8, 1.0), 3.0)
	var inner := CylinderMesh.new()
	inner.top_radius = 3.0
	inner.bottom_radius = 3.0
	inner.height = 0.04
	inner.radial_segments = 48
	Gfx.add_mesh(root, inner, c + Vector3(0, 0.125, 0), Gfx.tinted(Color(0.12, 0.14, 0.25)))
	for i in 12:
		var a := TAU * i / 12.0
		var r := Gfx.glow_node(root, Gfx.box_mesh(Vector3(0.18, 0.04, 0.5)), c + Vector3(cos(a) * 2.5, 0.16, sin(a) * 2.5), Color(0.5, 0.9, 1.0), 4.0)
		r.rotation.y = -a
	Gfx.disc(root, 1.2, 0.04, c + Vector3(0, 0.15, 0), Color(0.6, 0.5, 1.0), 2.5)
	var cr := CylinderMesh.new()
	cr.top_radius = 0.0
	cr.bottom_radius = 0.5
	cr.height = 1.2
	cr.radial_segments = 4
	var holder := Node3D.new()
	holder.position = c + Vector3(0, 2.6, 0)
	root.add_child(holder)
	var up := Gfx.glow_node(holder, cr, Vector3(0, 0.6, 0), Color(0.55, 0.85, 1.0), 4.0)
	var down := Gfx.glow_node(holder, cr, Vector3(0, -0.6, 0), Color(0.55, 0.85, 1.0), 4.0)
	down.rotation_degrees.x = 180.0
	up.rotation_degrees.x = 0.0
	Gfx.light(holder, Vector3.ZERO, Color(0.5, 0.85, 1.0), 2.5, 14.0)
	holder.add_child(_ps(Color(0.6, 0.9, 1.0), 40, 3.0, 0.14, Vector2(0.2, 0.8), 2.5, Vector3(0, 0.3, 0)))
	var tw := holder.create_tween().set_loops()
	tw.tween_property(holder, "rotation:y", TAU, 8.0).from(0.0)
	var bob := holder.create_tween().set_loops()
	bob.tween_property(holder, "position:y", c.y + 2.9, 2.0).set_trans(Tween.TRANS_SINE)
	bob.tween_property(holder, "position:y", c.y + 2.4, 2.0).set_trans(Tween.TRANS_SINE)


static func _exterior(root: Node3D) -> void:
	var e: Array = []
	e.append(Gfx.p_cyl(9.0, 9.2, 0.2, Vector3(0, 0.05, 19.0), Color(0.6, 0.58, 0.55), Vector3.ZERO, 40))
	# fuente
	e.append(Gfx.p_cyl(3.4, 3.6, 0.9, Vector3(0, 0.5, 19.0), STONE, Vector3.ZERO, 24))
	e.append(Gfx.p_cyl(0.5, 0.7, 2.2, Vector3(0, 1.6, 19.0), STONE, Vector3.ZERO, 12))
	e.append(Gfx.p_cyl(1.5, 0.5, 0.4, Vector3(0, 2.8, 19.0), STONE, Vector3.ZERO, 16))
	Gfx.body_cyl(root, 3.6, 1.0, Vector3(0, 0.5, 19.0))
	var water := CylinderMesh.new()
	water.top_radius = 3.1
	water.bottom_radius = 3.1
	water.height = 0.05
	water.radial_segments = 32
	Gfx.add_mesh(root, water, Vector3(0, 0.9, 19.0), Gfx.glass(Color(0.3, 0.7, 0.9, 0.6)))
	var spray: Node3D = _ps(Color(0.7, 0.9, 1.0), 40, 1.6, 0.18, Vector2(2.0, 3.4), 0.1, Vector3(0, -6.0, 0), 20.0)
	spray.position = Vector3(0, 3.0, 19.0)
	root.add_child(spray)
	Gfx.light(root, Vector3(0, 3.5, 19.0), Color(0.5, 0.8, 1.0), 1.2, 10.0)
	# pilares de entrada con braseros
	for sx in [-4.2, 4.2]:
		e.append(Gfx.p_cyl(0.6, 0.75, 7.0, Vector3(sx, 3.5, 12.5), STONE, Vector3.ZERO, 14))
		e.append(Gfx.p_cyl(1.0, 0.7, 0.8, Vector3(sx, 7.2, 12.5), GOLD, Vector3.ZERO, 14))
		Gfx.body_cyl(root, 0.75, 7.0, Vector3(sx, 3.5, 12.5))
		Gfx.glow_node(root, Gfx.sphere_mesh(0.4), Vector3(sx, 7.9, 12.5), Color(1.0, 0.55, 0.2), 4.0)
		Gfx.light(root, Vector3(sx, 8.4, 12.5), Color(1.0, 0.6, 0.3), 2.5, 16.0, true)
		var f: Node3D = _ps(Color(1.0, 0.6, 0.25), 24, 0.9, 0.35, Vector2(0.5, 1.2), 0.25, Vector3(0, 1.0, 0), 25.0)
		f.position = Vector3(sx, 8.0, 12.5)
		root.add_child(f)
	e.append(Gfx.p_box(Vector3(10.0, 1.0, 1.1), Vector3(0, 8.3, 11.5), STONE))
	# arbustos decorativos
	for i in 16:
		var a := TAU * i / 16.0
		var rr := 21.0
		var pos := Vector3(cos(a) * rr * 1.2, 0.5, sin(a) * rr * 0.95)
		if absf(pos.x) < 9.0 and pos.z > 10.0:
			continue
		e.append(Gfx.p_sph(1.3, pos, Color(0.15, 0.4, 0.15), Vector3(1.2, 0.8, 1.2), 8))
		e.append(Gfx.p_sph(0.35, pos + Vector3(0.6, 0.9, 0.3), Color(0.95, 0.5, 0.7), Vector3.ONE, 6))
	Gfx.add_mesh(root, Gfx.merge(e))
