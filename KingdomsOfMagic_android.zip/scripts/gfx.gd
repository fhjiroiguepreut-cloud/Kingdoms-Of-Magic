class_name Gfx
extends RefCounted
## Utilidades gráficas: materiales PBR, mallas fusionadas con color por vértice, luces y colisiones.

static var _mats := {}
static var stats := {}   # diagnóstico: segundos acumulados por categoría


static func acc(k: String, t0: int) -> void:
	stats[k] = float(stats.get(k, 0.0)) + (Time.get_ticks_usec() - t0) / 1000000.0


static func stats_text() -> String:
	var out := PackedStringArray()
	for k in stats:
		out.append("%s %.2fs" % [k, stats[k]])
	return " | ".join(out)


static func _noise_tex(freq: float, normal: bool, strength: float, grain: float) -> NoiseTexture2D:
	var n := FastNoiseLite.new()
	n.frequency = freq
	n.fractal_octaves = 4
	var t := NoiseTexture2D.new()
	t.noise = n
	t.width = 256 if OS.has_feature("mobile") else 512
	t.height = t.width
	t.seamless = true
	if normal:
		t.as_normal_map = true
		t.bump_strength = strength
	else:
		var g := Gradient.new()
		g.offsets = PackedFloat32Array([0.0, 1.0])
		g.colors = PackedColorArray([Color(1.0 - grain, 1.0 - grain, 1.0 - grain), Color.WHITE])
		t.color_ramp = g
	return t


static func pbr(rough: float = 0.85, tri_scale: float = 0.3, bump: float = 1.0, grain: float = 0.35) -> StandardMaterial3D:
	var t0 := Time.get_ticks_usec()
	var m := _pbr_impl(rough, tri_scale, bump, grain)
	acc("texturas", t0)
	return m


static func _pbr_impl(rough: float, tri_scale: float, bump: float, grain: float) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.vertex_color_use_as_albedo = true
	m.roughness = rough
	m.albedo_texture = _noise_tex(0.02, false, 0.0, grain)
	m.normal_enabled = true
	m.normal_texture = _noise_tex(0.03, true, 8.0, 0.0)
	m.normal_scale = bump
	m.uv1_triplanar = true
	m.uv1_world_triplanar = true
	m.uv1_scale = Vector3(tri_scale, tri_scale, tri_scale)
	return m


static func vc_mat() -> StandardMaterial3D:
	if not _mats.has("vc"):
		_mats["vc"] = pbr(0.8, 0.35, 0.8, 0.3)
	return _mats["vc"]


static func terrain_mat() -> StandardMaterial3D:
	if not _mats.has("terrain"):
		_mats["terrain"] = pbr(0.96, 0.22, 1.3, 0.45)
	return _mats["terrain"]


static func tinted(col: Color) -> StandardMaterial3D:
	var k := "t" + col.to_html()
	if not _mats.has(k):
		var m := vc_mat().duplicate() as StandardMaterial3D
		m.vertex_color_use_as_albedo = false
		m.albedo_color = col
		_mats[k] = m
	return _mats[k]


static func glow(col: Color, e: float = 3.0) -> StandardMaterial3D:
	var k := "g" + col.to_html() + str(e)
	if not _mats.has(k):
		var m := StandardMaterial3D.new()
		m.albedo_color = col
		m.emission_enabled = true
		m.emission = col
		m.emission_energy_multiplier = e
		_mats[k] = m
	return _mats[k]


static func glass(col: Color) -> StandardMaterial3D:
	var k := "gl" + col.to_html()
	if not _mats.has(k):
		var m := StandardMaterial3D.new()
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		m.albedo_color = col
		m.roughness = 0.06
		m.metallic_specular = 1.0
		m.emission_enabled = true
		m.emission = Color(col.r, col.g, col.b)
		m.emission_energy_multiplier = 0.5
		m.rim_enabled = true
		m.rim = 0.6
		_mats[k] = m
	return _mats[k]


static func window_mat() -> StandardMaterial3D:
	if not _mats.has("win"):
		var m := StandardMaterial3D.new()
		m.vertex_color_use_as_albedo = true
		m.emission_enabled = true
		m.emission = Color(1.0, 0.72, 0.35)
		m.emission_energy_multiplier = 2.2
		_mats["win"] = m
	return _mats["win"]


# ---------- Piezas para fusionar ----------
static func xf(pos: Vector3, rot_deg: Vector3 = Vector3.ZERO, scl: Vector3 = Vector3.ONE) -> Transform3D:
	var b := Basis.from_euler(Vector3(deg_to_rad(rot_deg.x), deg_to_rad(rot_deg.y), deg_to_rad(rot_deg.z)))
	b = b * Basis.from_scale(scl)
	return Transform3D(b, pos)


static var _geo := {}   # caché: clave de forma -> arrays de malla (se generan UNA sola vez por forma)


static func p_box(size: Vector3, pos: Vector3, col: Color, rot: Vector3 = Vector3.ZERO) -> Array:
	# Caja unitaria compartida, escalada por la transformación
	var m := BoxMesh.new()
	return [m, xf(pos, rot, size), col, "box", "rot"]


static func p_cyl(rt: float, rb: float, h: float, pos: Vector3, col: Color, rot: Vector3 = Vector3.ZERO, seg: int = 10) -> Array:
	var m := CylinderMesh.new()
	m.top_radius = rt
	m.bottom_radius = rb
	m.height = h
	m.radial_segments = seg
	m.rings = 1
	return [m, xf(pos, rot), col, "cyl|%s|%s|%s|%d" % [rt, rb, h, seg], "rot"]


static func p_sph(r: float, pos: Vector3, col: Color, scl: Vector3 = Vector3.ONE, seg: int = 12) -> Array:
	# Esfera unitaria compartida (radio 1), escalada por la transformación
	var m := SphereMesh.new()
	m.radius = 1.0
	m.height = 2.0
	m.radial_segments = seg
	m.rings = maxi(seg / 2, 2)
	var uniform := is_equal_approx(scl.x, scl.y) and is_equal_approx(scl.y, scl.z)
	return [m, xf(pos, Vector3.ZERO, scl * r), col, "sph|%d" % seg, "rot" if uniform else "gen"]


static func p_prism(size: Vector3, pos: Vector3, col: Color, rot: Vector3 = Vector3.ZERO) -> Array:
	var m := PrismMesh.new()
	m.size = size
	return [m, xf(pos, rot), col, "pri|%s" % str(size), "rot"]


static func merge(parts: Array) -> ArrayMesh:
	var t0 := Time.get_ticks_usec()
	var mesh := _merge_impl(parts)
	acc("mallas", t0)
	return mesh


static func _merge_impl(parts: Array) -> ArrayMesh:
	var verts := PackedVector3Array()
	var norms := PackedVector3Array()
	var uvs := PackedVector2Array()
	var cols := PackedColorArray()
	var inds := PackedInt32Array()
	for p in parts:
		var m: PrimitiveMesh = p[0]
		var t: Transform3D = p[1]
		var c: Color = p[2]
		var key: String = p[3]
		var flag: String = p[4]
		if not _geo.has(key):
			_geo[key] = m.get_mesh_arrays()   # única subida a la GPU por forma
		var arr: Array = _geo[key]
		var v: PackedVector3Array = arr[Mesh.ARRAY_VERTEX]
		var nrm: PackedVector3Array = arr[Mesh.ARRAY_NORMAL]
		var uv: PackedVector2Array = arr[Mesh.ARRAY_TEX_UV]
		var idx := PackedInt32Array()
		if arr[Mesh.ARRAY_INDEX] != null:
			idx = arr[Mesh.ARRAY_INDEX]
		var n := v.size()
		var base := verts.size()
		verts.append_array(t * v)
		var nb: Basis = t.basis.orthonormalized() if flag == "rot" else t.basis.inverse().transposed()
		var tn: PackedVector3Array = Transform3D(nb, Vector3.ZERO) * nrm
		if flag == "gen":
			for k in n:
				tn[k] = tn[k].normalized()
		norms.append_array(tn)
		uvs.append_array(uv)
		var cc := PackedColorArray()
		cc.resize(n)
		cc.fill(c)
		cols.append_array(cc)
		var off := inds.size()
		if idx.size() > 0:
			inds.resize(off + idx.size())
			for k in idx.size():
				inds[off + k] = base + idx[k]
		else:
			inds.resize(off + n)
			for k in n:
				inds[off + k] = base + k
	var mesh := ArrayMesh.new()
	if verts.is_empty():
		return mesh
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_NORMAL] = norms
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	arrays[Mesh.ARRAY_COLOR] = cols
	arrays[Mesh.ARRAY_INDEX] = inds
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	return mesh


# ---------- Nodos ----------
static func add_mesh(parent: Node, mesh: Mesh, pos: Vector3 = Vector3.ZERO, mat: Material = null) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.position = pos
	mi.material_override = mat if mat != null else vc_mat()
	parent.add_child(mi)
	return mi


static func solid(parent: Node, size: Vector3, pos: Vector3, col: Color, rot: Vector3 = Vector3.ZERO) -> StaticBody3D:
	var sb := StaticBody3D.new()
	sb.position = pos
	sb.rotation_degrees = rot
	parent.add_child(sb)
	var bm := BoxMesh.new()
	bm.size = size
	var mi := MeshInstance3D.new()
	mi.mesh = bm
	mi.material_override = tinted(col)
	sb.add_child(mi)
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = size
	cs.shape = bs
	sb.add_child(cs)
	return sb


static func body_box(parent: Node, size: Vector3, pos: Vector3, rot: Vector3 = Vector3.ZERO) -> StaticBody3D:
	var sb := StaticBody3D.new()
	sb.position = pos
	sb.rotation_degrees = rot
	parent.add_child(sb)
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = size
	cs.shape = bs
	sb.add_child(cs)
	return sb


static func body_cyl(parent: Node, radius: float, h: float, pos: Vector3) -> StaticBody3D:
	var sb := StaticBody3D.new()
	sb.position = pos
	parent.add_child(sb)
	var cs := CollisionShape3D.new()
	var s := CylinderShape3D.new()
	s.radius = radius
	s.height = h
	cs.shape = s
	sb.add_child(cs)
	return sb


static func light(parent: Node, pos: Vector3, col: Color, energy: float, rng: float = 8.0, flicker: bool = false, shadow: bool = false) -> OmniLight3D:
	var t0 := Time.get_ticks_usec()
	var l := _light_impl(parent, pos, col, energy, rng, flicker, shadow)
	acc("luces", t0)
	return l


static func _light_impl(parent: Node, pos: Vector3, col: Color, energy: float, rng: float, flicker: bool, shadow: bool) -> OmniLight3D:
	var l := OmniLight3D.new()
	l.position = pos
	l.light_color = col
	l.light_energy = energy
	l.omni_range = rng
	l.shadow_enabled = shadow
	l.light_volumetric_fog_energy = 1.0
	parent.add_child(l)
	if OS.has_feature("mobile"):
		l.shadow_enabled = false
		if energy <= 1.0:
			l.visible = false
		return l
	if flicker:
		var tw := l.create_tween().set_loops()
		tw.tween_property(l, "light_energy", energy * 0.78, 0.13 + randf() * 0.1)
		tw.tween_property(l, "light_energy", energy * 1.15, 0.17 + randf() * 0.1)
	return l


static func glow_node(parent: Node, mesh: Mesh, pos: Vector3, col: Color, e: float = 3.0) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.position = pos
	mi.material_override = glow(col, e)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	return mi


static func disc(parent: Node, r: float, h: float, pos: Vector3, col: Color, e: float = 3.0) -> MeshInstance3D:
	var m := CylinderMesh.new()
	m.top_radius = r
	m.bottom_radius = r
	m.height = h
	m.radial_segments = 48
	m.rings = 1
	return glow_node(parent, m, pos, col, e)


static func sphere_mesh(r: float) -> SphereMesh:
	var m := SphereMesh.new()
	m.radius = r
	m.height = r * 2.0
	m.radial_segments = 16
	m.rings = 8
	return m


static func box_mesh(size: Vector3) -> BoxMesh:
	var m := BoxMesh.new()
	m.size = size
	return m
